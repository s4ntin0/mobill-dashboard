# Mobill - Mobile Billboarding Platform

A Next.js application for managing mobile billboarding campaigns.

## Features

- User authentication
- Campaign management
- Location-based targeting
- Campaign analytics

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Shadcn/UI Components

## Local Development

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Setup

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd mobill

