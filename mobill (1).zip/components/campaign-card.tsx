"use client"

import { useState } from "react"
import type { Campaign } from "@/lib/campaign-service"
import { TrendingUp, Edit, MapPin, Clock, DollarSign, Calendar, ToggleLeft, ToggleRight, Map, List } from "lucide-react"
import { formatPointForDisplay } from "@/lib/location-utils"
import { useLanguage } from "@/lib/language-context"
import { CampaignAdLogs } from "./campaign-ad-logs"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CampaignSpots } from "./campaign-spots"

interface CampaignCardProps {
  campaign: Campaign
  onEdit: (campaign: Campaign) => void
  onToggleStatus: (campaign: Campaign) => void
}

export function CampaignCard({ campaign, onEdit, onToggleStatus }: CampaignCardProps) {
  const { t } = useLanguage()
  const [showDetails, setShowDetails] = useState(false)

  // Format the start date
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    } catch (e) {
      return dateString
    }
  }

  return (
    <div
      className={`p-6 rounded-lg border shadow-sm relative ${
        campaign.active
          ? "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
          : "bg-gray-50 dark:bg-gray-900 border-gray-300 dark:border-gray-800"
      }`}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <h3
            className={`text-xl font-bold ${
              campaign.active ? "text-black dark:text-white" : "text-gray-600 dark:text-gray-400"
            }`}
          >
            {campaign.name || campaign.description}
          </h3>
          <div
            className={`ml-2 px-2 py-1 text-xs rounded-full ${
              campaign.active
                ? "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 border border-green-200 dark:border-green-800"
                : "bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-300 border border-gray-300 dark:border-gray-600"
            }`}
          >
            {campaign.active ? t("campaign.active") : t("campaign.inactive")}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {campaign.active && <TrendingUp className="text-green-600 dark:text-green-400" size={20} />}
          <button
            onClick={() => onEdit(campaign)}
            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
            title={t("campaign.edit")}
            aria-label={t("campaign.edit")}
          >
            <Edit size={18} className="text-gray-700 dark:text-gray-300" />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {campaign.location && (
          <div className="flex items-start">
            <MapPin size={16} className="text-gray-700 dark:text-gray-300 mt-1 mr-2 flex-shrink-0" />
            <div className="text-sm text-gray-700 dark:text-gray-300">
              <span className="block">
                {t("radius")}: {campaign.radius ? `${campaign.radius}m` : "N/A"}
              </span>
              <span className="block text-xs text-gray-500 dark:text-gray-400 mt-1">
                {formatPointForDisplay(campaign.location)}
              </span>
            </div>
          </div>
        )}

        <div className="flex items-start">
          <Calendar size={16} className="text-gray-700 dark:text-gray-300 mt-1 mr-2 flex-shrink-0" />
          <div className="text-sm text-gray-700 dark:text-gray-300">
            <span className="block">
              {t("starts")}: {formatDate(campaign.start)}
            </span>
            <span className="block text-xs text-gray-500 dark:text-gray-400 mt-1">
              {t("duration")}: {campaign.duration} days
            </span>
          </div>
        </div>

        <div className="flex items-start">
          <DollarSign size={16} className="text-gray-700 dark:text-gray-300 mt-1 mr-2 flex-shrink-0" />
          <div className="text-sm text-gray-700 dark:text-gray-300">
            <span className="block">
              {t("daily_budget")}: ${campaign.daily_budget}
            </span>
            {campaign.budgetSpent !== undefined && (
              <span className="block text-xs text-gray-500 dark:text-gray-400 mt-1">
                {t("spent")}: ${campaign.budgetSpent.toLocaleString()}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-start">
          <Clock size={16} className="text-gray-700 dark:text-gray-300 mt-1 mr-2 flex-shrink-0" />
          <div className="text-sm text-gray-700 dark:text-gray-300">
            <span className="block">
              {t("road_type")}: {campaign.road_type}
            </span>
            <span className="block text-xs text-gray-500 dark:text-gray-400 mt-1">
              {t("traffic_density")}: {campaign.traffic_density}
            </span>
          </div>
        </div>

        {campaign.impressions !== undefined && (
          <div className="flex justify-between mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
            <div>
              <span className="text-xs text-gray-500 dark:text-gray-400">{t("impressions")}</span>
              <p className="font-medium text-black dark:text-white">{(campaign.impressions || 0).toLocaleString()}</p>
            </div>

            {campaign.minutes !== undefined && (
              <div>
                <span className="text-xs text-gray-500 dark:text-gray-400">{t("minutes")}</span>
                <p className="font-medium text-black dark:text-white">{(campaign.minutes || 0).toLocaleString()}</p>
              </div>
            )}
          </div>
        )}

        {/* View Details Button */}
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="mt-4 w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-colors bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/30 border border-blue-200 dark:border-blue-800"
        >
          {showDetails ? (
            <>
              <Map size={18} />
              Hide Map
            </>
          ) : (
            <>
              <Map size={18} />
              View Map
            </>
          )}
        </button>

        {/* Campaign Details Section */}
        {showDetails && (
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <Tabs defaultValue="map" className="w-full">
              <TabsList className="grid grid-cols-2 mb-4 w-full">
                <TabsTrigger value="map" className="flex items-center">
                  <Map className="h-4 w-4 mr-2" />
                  Map View
                </TabsTrigger>
                <TabsTrigger value="logs" className="flex items-center">
                  <List className="h-4 w-4 mr-2" />
                  Log Details
                </TabsTrigger>
              </TabsList>

              <TabsContent value="map" className="w-full">
                <CampaignAdLogs campaignId={campaign.id} />
              </TabsContent>

              <TabsContent value="logs" className="w-full">
                <CampaignSpots campaignId={campaign.id} />
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Toggle Status Button */}
        <button
          onClick={() => onToggleStatus(campaign)}
          className={`mt-4 w-full flex items-center justify-center gap-2 py-2 px-4 rounded-md transition-colors ${
            campaign.active
              ? "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-900/30 border border-red-200 dark:border-red-800"
              : "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/30 border border-green-200 dark:border-green-800"
          }`}
        >
          {campaign.active ? (
            <>
              <ToggleLeft size={18} />
              {t("campaign.deactivate")}
            </>
          ) : (
            <>
              <ToggleRight size={18} />
              {t("campaign.activate")}
            </>
          )}
        </button>
      </div>
    </div>
  )
}

