"use client"

import { useEffect, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet"
import L from "leaflet"
import type { AdDisplayLog } from "@/lib/types/ad-logs"
import "leaflet/dist/leaflet.css"

// Define a custom icon for the markers
const customIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  shadowSize: [41, 41],
})

interface MapComponentProps {
  logs: AdDisplayLog[]
}

export default function MapComponent({ logs }: MapComponentProps) {
  // Default center (Madrid, Spain)
  const defaultCenter: [number, number] = [40.416775, -3.70379]
  const [mapReady, setMapReady] = useState(false)

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleString()
    } catch (e) {
      return timestamp
    }
  }

  // Load CSS
  useEffect(() => {
    setMapReady(true)
  }, [])

  if (!mapReady) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
      </div>
    )
  }

  // Calculate bounds to fit all markers
  const bounds = L.latLngBounds([])
  logs.forEach((log) => {
    let lat, lng
    if (log.latitude && log.longitude) {
      lat = log.latitude
      lng = log.longitude
    } else if (log.location?.coordinates) {
      // GeoJSON format is [longitude, latitude]
      lng = log.location.coordinates[0]
      lat = log.location.coordinates[1]
    }

    if (lat && lng) {
      bounds.extend([lat, lng])
    }
  })

  return (
    <div className="h-[500px] w-full rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
      <MapContainer
        center={defaultCenter}
        zoom={13}
        style={{ height: "100%", width: "100%" }}
        bounds={bounds.isValid() ? bounds : undefined}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {logs.map((log) => {
          let position: [number, number] | null = null

          if (log.latitude && log.longitude) {
            position = [log.latitude, log.longitude]
          } else if (log.location?.coordinates) {
            // GeoJSON format is [longitude, latitude]
            position = [log.location.coordinates[1], log.location.coordinates[0]]
          }

          if (!position) return null

          return (
            <Marker key={log.id} position={position} icon={customIcon}>
              <Popup>
                <div className="p-2">
                  <h3 className="font-bold text-sm mb-2">Ad Display #{log.id}</h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center">
                      <span>Time: {formatTimestamp(log.timestamp)}</span>
                    </div>
                    <div className="flex items-center">
                      <span>Vehicle Speed: {log.vehicle_speed} km/h</span>
                    </div>
                    <div className="flex items-center">
                      <span>Road Type: {log.road_type}</span>
                    </div>
                    <div className="flex items-center">
                      <span>Traffic Density: {log.traffic_density}</span>
                    </div>
                    <div className="mt-1 pt-1 border-t border-gray-200">
                      <span className="font-medium">Price: ${log.price.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          )
        })}
      </MapContainer>
    </div>
  )
}

