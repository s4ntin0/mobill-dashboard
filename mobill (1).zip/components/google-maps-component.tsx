"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { GoogleMap, InfoWindow, Marker } from "@react-google-maps/api"
import type { AdDisplayLog } from "@/lib/types/ad-logs"
import { Clock, Navigation, RouteIcon as Road, Gauge, MapPin } from "lucide-react"

// Define the container style
const containerStyle = {
  width: "100%",
  height: "500px",
}

// Default center (Madrid, Spain)
const defaultCenter = {
  lat: 40.416775,
  lng: -3.70379,
}

// Custom map styles for a cleaner look
const mapStyles = [
  {
    featureType: "administrative",
    elementType: "labels.text.fill",
    stylers: [{ color: "#444444" }],
  },
  {
    featureType: "landscape",
    elementType: "all",
    stylers: [{ color: "#f2f2f2" }],
  },
  {
    featureType: "poi",
    elementType: "all",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "road",
    elementType: "all",
    stylers: [{ saturation: -100 }, { lightness: 45 }],
  },
  {
    featureType: "road.highway",
    elementType: "all",
    stylers: [{ visibility: "simplified" }],
  },
  {
    featureType: "road.arterial",
    elementType: "labels.icon",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "transit",
    elementType: "all",
    stylers: [{ visibility: "off" }],
  },
  {
    featureType: "water",
    elementType: "all",
    stylers: [{ color: "#c4e5f9" }, { visibility: "on" }],
  },
]

interface GoogleMapsComponentProps {
  logs: AdDisplayLog[]
}

export default function GoogleMapsComponent({ logs }: GoogleMapsComponentProps) {
  // State for Google Maps loading
  const [isLoaded, setIsLoaded] = useState(false)
  const [loadError, setLoadError] = useState<Error | null>(null)
  const [configLoaded, setConfigLoaded] = useState(false)

  // Map state
  const [map, setMap] = useState<google.maps.Map | null>(null)
  const [selectedMarker, setSelectedMarker] = useState<AdDisplayLog | null>(null)
  const [markers, setMarkers] = useState<{ position: google.maps.LatLngLiteral; log: AdDisplayLog }[]>([])
  const [advancedMarkers, setAdvancedMarkers] = useState<any[]>([])
  const mapRef = useRef<google.maps.Map | null>(null)
  const [mapConfig, setMapConfig] = useState<{ mapId: string; hasApiKey: boolean }>({
    mapId: "467c6dfd66cd4cf8", // Use the provided Map ID directly as a fallback
    hasApiKey: !!process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY,
  })

  // Check if Google Maps is loaded
  useEffect(() => {
    // Check if Google Maps is already loaded
    if (typeof window !== "undefined" && window.google && window.google.maps) {
      console.log("Google Maps already loaded")
      setIsLoaded(true)
      return
    }

    // Set up a listener for when the Google Maps script loads
    const handleGoogleMapsLoaded = () => {
      console.log("Google Maps loaded via event listener")
      setIsLoaded(true)
    }

    window.addEventListener("google-maps-loaded", handleGoogleMapsLoaded)

    // Check periodically if Google Maps has loaded
    const checkInterval = setInterval(() => {
      if (typeof window !== "undefined" && window.google && window.google.maps) {
        console.log("Google Maps loaded via interval check")
        setIsLoaded(true)
        clearInterval(checkInterval)
        window.dispatchEvent(new Event("google-maps-loaded"))
      }
    }, 500)

    // Set a timeout to stop checking after 10 seconds
    const timeoutId = setTimeout(() => {
      if (!isLoaded) {
        clearInterval(checkInterval)
        setLoadError(new Error("Google Maps failed to load"))
        console.error("Google Maps failed to load after timeout")
      }
    }, 10000)

    return () => {
      window.removeEventListener("google-maps-loaded", handleGoogleMapsLoaded)
      clearInterval(checkInterval)
      clearTimeout(timeoutId)
    }
  }, [isLoaded])

  // Fetch map configuration from the server
  useEffect(() => {
    fetch("/api/maps-config")
      .then((res) => res.json())
      .then((data) => {
        setMapConfig(data)
        setConfigLoaded(true)
        console.log("Map configuration loaded:", { mapId: data.mapId, hasApiKey: data.hasApiKey })
      })
      .catch((err) => {
        console.error("Failed to load map configuration:", err)
        // Use the default mapId we set in the initial state
        setConfigLoaded(true)
      })
  }, [])

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleString()
    } catch (e) {
      return timestamp
    }
  }

  // Process logs to extract valid coordinates
  useEffect(() => {
    if (logs.length > 0) {
      const validMarkers = logs
        .map((log) => {
          let position: google.maps.LatLngLiteral | null = null

          if (log.latitude && log.longitude) {
            position = { lat: log.latitude, lng: log.longitude }
          } else if (log.location?.coordinates) {
            // GeoJSON format is [longitude, latitude]
            position = { lat: log.location.coordinates[1], lng: log.location.coordinates[0] }
          }

          return position ? { position, log } : null
        })
        .filter((marker): marker is { position: google.maps.LatLngLiteral; log: AdDisplayLog } => marker !== null)

      setMarkers(validMarkers)
      console.log(`Processed ${validMarkers.length} valid markers from ${logs.length} logs`)
    }
  }, [logs])

  // Create markers when map and marker data are available
  useEffect(() => {
    if (!map || markers.length === 0 || !isLoaded) return

    // Clean up any existing markers
    advancedMarkers.forEach((marker) => {
      if (marker && marker.map) {
        marker.map = null
      }
    })

    // Check if we have a Map ID and can use AdvancedMarkerElement
    const mapId = mapConfig.mapId
    const hasAdvancedMarkers =
      typeof window !== "undefined" && window.google?.maps?.marker?.AdvancedMarkerElement && mapId

    if (hasAdvancedMarkers) {
      console.log("Using AdvancedMarkerElement with Map ID:", mapId)
      try {
        // Create new advanced markers
        const newAdvancedMarkers = markers
          .map(({ position, log }, index) => {
            try {
              // Create marker element
              const markerElement = document.createElement("div")
              markerElement.className = "marker-container"
              markerElement.innerHTML = `
              <div class="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white relative">
                <div class="absolute w-2 h-2 bg-blue-600 rotate-45 -bottom-1 left-1/2 transform -translate-x-1/2"></div>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
              </div>
            `

              // Create the advanced marker
              const AdvancedMarkerElement = window.google.maps.marker.AdvancedMarkerElement
              const advancedMarker = new AdvancedMarkerElement({
                map,
                position,
                content: markerElement,
                title: `Ad Display #${log.id}`,
              })

              // Add click event listener
              advancedMarker.addListener("click", () => {
                setSelectedMarker(log)
              })

              return advancedMarker
            } catch (err) {
              console.error("Error creating advanced marker:", err)
              return null
            }
          })
          .filter((marker) => marker !== null)

        setAdvancedMarkers(newAdvancedMarkers)

        // Add CSS for markers
        if (!document.getElementById("marker-styles")) {
          const style = document.createElement("style")
          style.id = "marker-styles"
          style.textContent = `
            .marker-container {
              cursor: pointer;
              transform: translate(-50%, -100%);
            }
          `
          document.head.appendChild(style)
        }
      } catch (err) {
        console.error("Error setting up advanced markers:", err)
        setAdvancedMarkers([])
      }
    } else {
      // If Map ID is not available, we can't use AdvancedMarkerElement
      console.warn(
        "Map ID is not configured or AdvancedMarkerElement is not available. " +
          "Using deprecated Marker component instead. " +
          "Please provide a valid Map ID in your environment variables as NEXT_PUBLIC_GOOGLE_MAPS_ID.",
      )
      setAdvancedMarkers([])
    }
  }, [map, markers, mapConfig.mapId, isLoaded])

  // Callback when the map is loaded
  const onLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map
    setMap(map)
    console.log("Map loaded successfully")
  }, [])

  // Callback when the map is unmounted
  const onUnmount = useCallback(() => {
    // Clean up markers
    advancedMarkers.forEach((marker) => {
      if (marker && marker.map) {
        marker.map = null
      }
    })
    setAdvancedMarkers([])

    mapRef.current = null
    setMap(null)
  }, [advancedMarkers])

  // Fit bounds to markers when markers change
  useEffect(() => {
    if (map && markers.length > 0 && isLoaded) {
      try {
        const bounds = new window.google.maps.LatLngBounds()

        markers.forEach(({ position }) => {
          bounds.extend(position)
        })

        map.fitBounds(bounds)

        // If we only have one marker or bounds are too small, set zoom level
        if (markers.length === 1 || bounds.getNorthEast().equals(bounds.getSouthWest())) {
          map.setZoom(14)
          map.setCenter(markers[0].position)
        }

        console.log(`Map bounds set to fit ${markers.length} markers`)
      } catch (err) {
        console.error("Error setting map bounds:", err)
      }
    }
  }, [map, markers, isLoaded])

  // Show loading state if Google Maps or config is not loaded yet
  if (loadError) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <div className="text-red-500 flex flex-col items-center">
          <MapPin className="h-8 w-8 mb-2" />
          <p>Error loading Google Maps: {loadError.message}</p>
          <p className="text-sm mt-2">Please check your API key configuration.</p>
        </div>
      </div>
    )
  }

  if (!isLoaded || !configLoaded) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
      </div>
    )
  }

  // Fallback to Leaflet map if Google Maps fails to load
  if (!window.google || !window.google.maps) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <div className="text-red-500 flex flex-col items-center">
          <MapPin className="h-8 w-8 mb-2" />
          <p>Google Maps is not available</p>
          <p className="text-sm mt-2">Falling back to basic map display.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-[500px] w-full rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 relative">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={defaultCenter}
        zoom={10}
        onLoad={onLoad}
        onUnmount={onUnmount}
        options={{
          fullscreenControl: false,
          streetViewControl: false,
          mapTypeControl: true,
          zoomControl: true,
          styles: mapStyles,
          mapTypeId: window.google.maps.MapTypeId.ROADMAP,
          mapId: mapConfig.mapId || undefined, // Use undefined instead of empty string if no mapId
        }}
      >
        {/* Display marker count */}
        <div className="absolute top-2 right-2 bg-white dark:bg-gray-800 px-3 py-1 rounded-md shadow-md z-10 text-sm">
          <span className="font-medium">{markers.length}</span> ad locations
        </div>

        {/* Use regular Markers if AdvancedMarkerElement can't be used */}
        {(!mapConfig.mapId || advancedMarkers.length === 0) &&
          markers.map(({ position, log }, index) => (
            <Marker
              key={`${log.id}-${index}`}
              position={position}
              onClick={() => setSelectedMarker(log)}
              icon={{
                url: "/ad-marker.svg",
                scaledSize: new window.google.maps.Size(32, 32),
                origin: new window.google.maps.Point(0, 0),
                anchor: new window.google.maps.Point(16, 32),
              }}
              title={`Ad Display #${log.id}`}
            />
          ))}

        {selectedMarker && (
          <InfoWindow
            position={
              selectedMarker.latitude && selectedMarker.longitude
                ? { lat: selectedMarker.latitude, lng: selectedMarker.longitude }
                : selectedMarker.location?.coordinates
                  ? { lat: selectedMarker.location.coordinates[1], lng: selectedMarker.location.coordinates[0] }
                  : defaultCenter
            }
            onCloseClick={() => setSelectedMarker(null)}
          >
            <div className="p-2 max-w-[250px]">
              <h3 className="font-bold text-sm mb-2">Ad Display #{selectedMarker.id}</h3>
              <div className="space-y-2 text-xs">
                <div className="flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>{formatTimestamp(selectedMarker.timestamp)}</span>
                </div>
                <div className="flex items-center">
                  <Navigation className="h-3 w-3 mr-1" />
                  <span>Vehicle Speed: {selectedMarker.vehicle_speed} km/h</span>
                </div>
                <div className="flex items-center">
                  <Road className="h-3 w-3 mr-1" />
                  <span>Road Type: {selectedMarker.road_type}</span>
                </div>
                <div className="flex items-center">
                  <Gauge className="h-3 w-3 mr-1" />
                  <span>Traffic Density: {selectedMarker.traffic_density}</span>
                </div>
                <div className="mt-1 pt-1 border-t border-gray-200">
                  <span className="font-medium">Price: ${(selectedMarker.price || 0).toFixed(2)}</span>
                </div>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </div>
  )
}

