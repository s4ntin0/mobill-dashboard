"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { formatPoint, parsePoint } from "@/lib/location-utils"
import {
  type Campaign,
  type Market,
  type RoadType,
  type TrafficDensity,
  getMarkets,
  getRoadTypes,
  getTrafficDensities,
  updateCampaign,
} from "@/lib/campaign-service"

interface CampaignFormProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  campaign: Campaign | undefined
  isEditing?: boolean
}

export function CampaignForm({ isOpen, onClose, onSuccess, campaign, isEditing = true }: CampaignFormProps) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [uploadProgress, setUploadProgress] = useState<number>(0)

  // Form data state
  const [formData, setFormData] = useState<Partial<Campaign>>({})

  // Location state
  const [useLocation, setUseLocation] = useState(false)
  const [longitude, setLongitude] = useState<string>("")
  const [latitude, setLatitude] = useState<string>("")

  // Ad upload state
  const [adFile, setAdFile] = useState<File | null>(null)
  const [adName, setAdName] = useState<string>("")
  const [adDescription, setAdDescription] = useState<string>("")

  // Reference data
  const [markets, setMarkets] = useState<Market[]>([])
  const [roadTypes, setRoadTypes] = useState<RoadType[]>([])
  const [trafficDensities, setTrafficDensities] = useState<TrafficDensity[]>([])
  const [dataLoading, setDataLoading] = useState(true)

  // Initialize form data when campaign changes
  useEffect(() => {
    if (campaign && isEditing) {
      setFormData({
        description: campaign.description,
        start: campaign.start,
        duration: campaign.duration,
        ad: campaign.ad,
        market: campaign.market,
        daily_budget: campaign.daily_budget,
        show_on_weekends: campaign.show_on_weekends,
        road_type: campaign.road_type,
        traffic_density: campaign.traffic_density,
      })

      // Set location data if available
      if (campaign.location) {
        setUseLocation(true)
        const point = parsePoint(campaign.location)
        if (point) {
          setLongitude(point.longitude.toString())
          setLatitude(point.latitude.toString())
        }
      } else {
        setUseLocation(false)
        setLongitude("-3.690457132960527") // Default longitude
        setLatitude("40.18760661754005") // Default latitude
      }

      // Set radius if available
      if (campaign.radius) {
        setFormData((prev) => ({ ...prev, radius: campaign.radius }))
      }
    }

    // Load reference data
    if (isOpen && user?.tokens.access) {
      fetchReferenceData()
    }
  }, [campaign, isEditing, isOpen, user])

  // Fetch reference data (markets, road types, traffic densities)
  const fetchReferenceData = async () => {
    if (!user?.tokens.access) return

    try {
      setDataLoading(true)

      // Fetch data in parallel
      const [marketsData, roadTypesData, trafficDensitiesData] = await Promise.all([
        getMarkets(user.tokens.access),
        getRoadTypes(),
        getTrafficDensities(),
      ])

      setMarkets(marketsData)
      setRoadTypes(roadTypesData)
      setTrafficDensities(trafficDensitiesData)
    } catch (err) {
      console.error("Error fetching form data:", err)
      setError("Failed to load form data. Please try again.")
    } finally {
      setDataLoading(false)
    }
  }

  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: Number.parseInt(value, 10) }))
  }

  const handleBooleanChange = (name: string, value: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    if (name === "road_type" || name === "traffic_density") {
      setFormData((prev) => ({ ...prev, [name]: value }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: Number.parseInt(value, 10) }))
    }
  }

  const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    if (name === "longitude") {
      setLongitude(value)
    } else if (name === "latitude") {
      setLatitude(value)
    }
  }

  const toggleLocationUsage = (checked: boolean) => {
    setUseLocation(checked)
  }

  const handleAdFileChange = (file: File | null, name: string, description: string) => {
    setAdFile(file)
    setAdName(name)
    setAdDescription(description)
    setUploadError(null)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setUploadError(null)

    try {
      if (!user?.tokens.access) {
        throw new Error("You must be logged in")
      }

      if (!campaign?.id) {
        throw new Error("Campaign ID is missing")
      }

      // Prepare campaign data for update
      const campaignData: Partial<Campaign> = {
        ...formData,
        // Only include location if it's being used
        location: useLocation ? formatPoint(Number.parseFloat(longitude), Number.parseFloat(latitude)) : null,
        radius: useLocation ? formData.radius : null,
      }

      console.log(`Updating campaign ${campaign.id} with data:`, campaignData)

      // Update the campaign
      await updateCampaign(campaign.id, campaignData, user.tokens.access)

      // Notify parent components of success
      onSuccess()
      onClose()
    } catch (err) {
      console.error("Campaign update error:", err)
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError("An unexpected error occurred")
      }
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t("campaign.edit")}</DialogTitle>
          <DialogDescription>{t("campaign.description")}</DialogDescription>
        </DialogHeader>

        {error && (
          <div className="bg-red-500 bg-opacity-20 border border-red-500 text-red-500 px-4 py-2 rounded mb-4">
            {error}
          </div>
        )}

        {dataLoading ? (
          <div className="py-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>{t("general.loading")}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Campaign Information */}
            <div className="border-b border-gray-300 pb-4 mb-4">
              <h2 className="text-xl font-semibold mb-4 text-black">{t("campaign.basicInfo")}</h2>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-gray-800">
                  {t("campaign.campaignDescription")}
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formData.description || ""}
                  onChange={handleChange}
                  rows={3}
                  required
                  className="bg-white text-black border-gray-300"
                  placeholder={t("campaign.campaignDescription")}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="start" className="text-gray-800">
                    {t("campaign.startDate")}
                  </Label>
                  <Input
                    id="start"
                    name="start"
                    type="date"
                    value={formData.start || ""}
                    onChange={handleChange}
                    required
                    className="bg-white text-black border-gray-300"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration" className="text-gray-800">
                    {t("campaign.duration")}
                  </Label>
                  <Input
                    id="duration"
                    name="duration"
                    type="number"
                    min="1"
                    value={formData.duration || ""}
                    onChange={handleNumberChange}
                    required
                    className="bg-white text-black border-gray-300"
                  />
                </div>
              </div>

              <div className="space-y-2 mt-4">
                <Label htmlFor="daily_budget" className="text-gray-800">
                  {t("campaign.dailyBudget")}
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                  <Input
                    id="daily_budget"
                    name="daily_budget"
                    type="text"
                    value={formData.daily_budget || ""}
                    onChange={handleChange}
                    required
                    className="bg-white text-black border-gray-300 pl-8"
                  />
                </div>
              </div>
            </div>

            {/* Market Selection */}
            <div className="border-b border-gray-300 pb-4 mb-4">
              <h2 className="text-xl font-semibold mb-4 text-black">{t("campaign.contentMarket")}</h2>

              <div className="space-y-2">
                <Label htmlFor="market" className="text-gray-800">
                  {t("campaign.market")}
                </Label>
                <Select
                  value={formData.market?.toString() || ""}
                  onValueChange={(value) => handleSelectChange("market", value)}
                >
                  <SelectTrigger id="market" className="bg-white text-black border-gray-300">
                    <SelectValue placeholder={t("campaign.market")} />
                  </SelectTrigger>
                  <SelectContent>
                    {markets.map((market) => (
                      <SelectItem key={market.id} value={market.id.toString()}>
                        {market.name} ({market.city}, {market.country})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Location Targeting */}
            <div className="border-b border-gray-300 pb-4 mb-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-black">{t("campaign.locationTargeting")}</h2>
                <div className="flex items-center space-x-2">
                  <Checkbox id="useLocation" checked={useLocation} onCheckedChange={toggleLocationUsage} />
                  <Label htmlFor="useLocation" className="text-sm font-medium text-gray-700 cursor-pointer">
                    {t("campaign.enableLocation")}
                  </Label>
                </div>
              </div>

              {useLocation ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                    <div className="space-y-2">
                      <Label htmlFor="longitude" className="text-gray-800">
                        {t("campaign.longitude")}
                      </Label>
                      <Input
                        id="longitude"
                        name="longitude"
                        type="text"
                        value={longitude}
                        onChange={handleLocationChange}
                        required={useLocation}
                        className="bg-white text-black border-gray-300"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="latitude" className="text-gray-800">
                        {t("campaign.latitude")}
                      </Label>
                      <Input
                        id="latitude"
                        name="latitude"
                        type="text"
                        value={latitude}
                        onChange={handleLocationChange}
                        required={useLocation}
                        className="bg-white text-black border-gray-300"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="radius" className="text-gray-800">
                      {t("campaign.radius")}
                    </Label>
                    <Input
                      id="radius"
                      name="radius"
                      type="number"
                      min="100"
                      max="10000"
                      value={formData.radius || 1000}
                      onChange={handleNumberChange}
                      required={useLocation}
                      className="bg-white text-black border-gray-300"
                    />
                  </div>
                </>
              ) : (
                <p className="text-gray-500 italic">{t("campaign.locationDisabled")}</p>
              )}
            </div>

            {/* Targeting Options */}
            <div className="border-b border-gray-300 pb-4 mb-4">
              <h2 className="text-xl font-semibold mb-4 text-black">{t("campaign.targetingOptions")}</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <div className="space-y-2">
                  <Label htmlFor="road_type" className="text-gray-800">
                    {t("campaign.roadType")}
                  </Label>
                  <Select
                    value={formData.road_type || ""}
                    onValueChange={(value) => handleSelectChange("road_type", value)}
                  >
                    <SelectTrigger id="road_type" className="bg-white text-black border-gray-300">
                      <SelectValue placeholder={t("campaign.roadType")} />
                    </SelectTrigger>
                    <SelectContent>
                      {roadTypes.map((roadType) => (
                        <SelectItem key={roadType.id} value={roadType.id}>
                          {roadType.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="traffic_density" className="text-gray-800">
                    {t("campaign.trafficDensity")}
                  </Label>
                  <Select
                    value={formData.traffic_density || ""}
                    onValueChange={(value) => handleSelectChange("traffic_density", value)}
                  >
                    <SelectTrigger id="traffic_density" className="bg-white text-black border-gray-300">
                      <SelectValue placeholder={t("campaign.trafficDensity")} />
                    </SelectTrigger>
                    <SelectContent>
                      {trafficDensities.map((density) => (
                        <SelectItem key={density.id} value={density.id}>
                          {density.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="show_on_weekends"
                    checked={formData.show_on_weekends}
                    onCheckedChange={(checked) => handleBooleanChange("show_on_weekends", !!checked)}
                  />
                  <Label htmlFor="show_on_weekends" className="text-gray-800 cursor-pointer">
                    {t("campaign.showWeekends")}
                  </Label>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 bg-white"
              >
                {t("campaign.cancel")}
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                disabled={loading}
              >
                {loading ? t("general.loading") : t("campaign.update")}
              </button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}

