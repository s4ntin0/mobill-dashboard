"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import type { AdDisplayLog } from "@/lib/types/ad-logs"
import { getAdDisplayLogs, generateSampleAdLogs } from "@/lib/ad-logs-service"
import { AdLogsMap } from "./ad-logs-map"
import { RefreshCw, Map, AlertTriangle } from "lucide-react"

interface CampaignAdLogsProps {
  campaignId: string
}

export function CampaignAdLogs({ campaignId }: CampaignAdLogsProps) {
  const { user } = useAuth()
  const [logs, setLogs] = useState<AdDisplayLog[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isVisible, setIsVisible] = useState(true)
  const [usingSampleData, setUsingSampleData] = useState(false)

  useEffect(() => {
    if (user?.tokens.access) {
      fetchAdLogs()
    }
  }, [campaignId, user?.tokens.access])

  const fetchAdLogs = async () => {
    if (!user?.tokens.access) return

    try {
      setLoading(true)
      setError(null)
      setUsingSampleData(false)

      try {
        const response = await getAdDisplayLogs(campaignId, user.tokens.access)

        if (response.data && response.data.length > 0) {
          console.log(`Fetched ${response.data.length} ad logs for campaign ${campaignId}`)
          setLogs(response.data)
        } else {
          console.log("No ad logs found, generating sample data")
          // Generate sample data if no logs are returned
          const sampleData = generateSampleAdLogs(campaignId, 20)
          setLogs(sampleData)
          setUsingSampleData(true)
        }
      } catch (err) {
        console.error("Error fetching ad logs:", err)
        setError(err instanceof Error ? err.message : "Failed to load ad display logs")

        // For demo purposes, generate sample data if the API fails
        console.log("Generating sample data due to API error")
        const sampleData = generateSampleAdLogs(campaignId, 20)
        setLogs(sampleData)
        setUsingSampleData(true)
      }
    } finally {
      setLoading(false)
    }
  }

  const toggleMapVisibility = () => {
    setIsVisible(!isVisible)
  }

  // Count logs with valid coordinates
  const validLocationCount = logs.filter(
    (log) => (log.latitude && log.longitude) || (log.location?.coordinates && log.location.coordinates.length === 2),
  ).length

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Ad Display Locations</h3>
        <button
          onClick={fetchAdLogs}
          className="flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
          disabled={loading}
        >
          <RefreshCw size={16} className={`mr-1 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {usingSampleData && (
        <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300 px-4 py-3 rounded-md flex items-start">
          <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">Using sample data</p>
            <p className="text-sm">This is demo data and does not represent actual campaign performance.</p>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md border border-gray-200 dark:border-gray-700">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Total locations:</span>
            <span className="ml-2 font-medium">{validLocationCount}</span>
          </div>
          <button
            onClick={toggleMapVisibility}
            className="py-1 px-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-md border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/30 flex items-center justify-center gap-2 text-sm"
          >
            <Map size={14} />
            {isVisible ? "Hide Map" : "Show Map"}
          </button>
        </div>
      </div>

      {isVisible && <AdLogsMap logs={logs} isLoading={loading} />}
    </div>
  )
}

