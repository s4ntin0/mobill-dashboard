"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useLanguage } from "@/lib/language-context"
import { loadStripe } from "@stripe/stripe-js"
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js"
import { CheckCircle } from "lucide-react"

// Initialize Stripe with your publishable key
const stripePromise = loadStripe(
  "pk_test_51R4qaKRsimENOlwtexE8ga77y2wILAvU9ntr75pK0DE1IhesZMR44UAzbG5xYvrOqWqvld6oew2qOOFiwAj5bWdP00LpF9iKs7",
)

interface PaymentFormProps {
  setupIntentClientSecret?: string | null
  customerSessionClientSecret?: string | null
  onSuccess?: () => void
}

function PaymentForm({
  setupIntentClientSecret,
  onSuccess,
}: { setupIntentClientSecret?: string | null; onSuccess?: () => void }) {
  const { t } = useLanguage()
  const stripe = useStripe()
  const elements = useElements()
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)

  useEffect(() => {
    if (!stripe) {
      console.log("Stripe.js hasn't loaded yet")
    } else {
      console.log("Stripe.js has loaded successfully")
    }

    if (!elements) {
      console.log("Elements hasn't initialized yet")
    } else {
      console.log("Elements has initialized successfully")
    }
  }, [stripe, elements])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!stripe || !elements) {
      setErrorMessage("Stripe is still loading. Please try again in a moment.")
      return
    }

    setIsLoading(true)
    setErrorMessage(null)
    setSuccessMessage(null)

    try {
      console.log("Submitting payment form...")

      // Step 1: Submit the form to collect payment details
      const { error: submitError } = await elements.submit()

      if (submitError) {
        console.error("Elements submit error:", submitError)
        console.log("Error details:", JSON.stringify(submitError, null, 2))
        setErrorMessage(submitError.message || "An error occurred")
        setIsLoading(false)
        return
      }

      console.log("Payment form submitted successfully")

      // If we have a setupIntentClientSecret, we need to confirm the setup
      if (setupIntentClientSecret) {
        console.log("Confirming SetupIntent...")

        // Get the current URL to use as the return_url
        const currentUrl = window.location.href

        const { error: confirmError, setupIntent } = await stripe.confirmSetup({
          elements,
          clientSecret: setupIntentClientSecret,
          redirect: "if_required",
          confirmParams: {
            // Use the current URL as the return_url
            return_url: currentUrl,
            // Removed the problematic payment_method_options parameter
          },
        })

        if (confirmError) {
          console.error("Confirm setup error:", confirmError)
          setErrorMessage(confirmError.message || "An error occurred during confirmation")
          setIsLoading(false)
          return
        }

        console.log("Setup confirmed successfully:", setupIntent?.status)

        // Check if the setup requires additional actions
        if (setupIntent?.status === "requires_action") {
          console.log("Setup requires additional action")
          setErrorMessage("This payment method requires additional verification. Please try again.")
          setIsLoading(false)
          return
        }
      }

      // If no error, the payment method was successfully set up
      setSuccessMessage("Your card has been successfully saved.")

      // Call the onSuccess callback if provided
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error("Payment error:", error)

      // Check if the error is because the card is already added
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred"
      console.log("Error message:", errorMessage)

      if (
        errorMessage.includes("already exists") ||
        errorMessage.includes("already attached") ||
        errorMessage.includes("processing error")
      ) {
        // Show success message instead of error
        setSuccessMessage("This card has already been added to your account.")

        // Call the onSuccess callback if provided
        if (onSuccess) {
          onSuccess()
        }
      } else {
        // Show regular error message
        setErrorMessage(errorMessage)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />

      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">{errorMessage}</div>
      )}

      {successMessage && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-md flex items-start">
          <CheckCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      <button
        type="submit"
        disabled={!stripe || isLoading}
        className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? t("billing.processing") : t("billing.save")}
      </button>
    </form>
  )
}

export function StripePaymentElement({
  setupIntentClientSecret,
  customerSessionClientSecret,
  onSuccess,
}: PaymentFormProps) {
  const [stripeError, setStripeError] = useState<string | null>(null)

  if (!customerSessionClientSecret) {
    return (
      <div className="py-4 text-center text-gray-500">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p>Waiting for payment information...</p>
      </div>
    )
  }

  // Log the client secrets (first few characters) for debugging
  console.log("CustomerSession client secret (first 10 chars):", customerSessionClientSecret.substring(0, 10) + "...")
  if (setupIntentClientSecret) {
    console.log("SetupIntent client secret (first 10 chars):", setupIntentClientSecret.substring(0, 10) + "...")
  }

  // Configure Stripe Elements according to the documentation
  // https://docs.stripe.com/payments/save-and-reuse#enable-saving-the-payment-method-in-the-payment-element
  const options = {
    mode: "setup" as const,
    currency: "usd",
    customerSessionClientSecret: customerSessionClientSecret,
    appearance: {
      theme: "stripe" as const,
      variables: {
        colorPrimary: "#3F5EFB",
      },
    },
  }

  console.log(
    "Stripe Elements options:",
    JSON.stringify(
      {
        ...options,
        customerSessionClientSecret: "[REDACTED]",
      },
      null,
      2,
    ),
  )

  return (
    <>
      {stripeError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md mb-4">{stripeError}</div>
      )}
      <Elements
        stripe={stripePromise}
        options={options}
        onLoadError={(error) => {
          console.error("Stripe Elements load error:", error)
          console.log("Error details:", JSON.stringify(error, null, 2))
          setStripeError(`Error loading Stripe: ${error.message}`)
        }}
      >
        <PaymentForm setupIntentClientSecret={setupIntentClientSecret} onSuccess={onSuccess} />
      </Elements>
    </>
  )
}

