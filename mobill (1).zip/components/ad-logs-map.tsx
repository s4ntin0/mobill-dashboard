"use client"
import dynamic from "next/dynamic"
import { useState, useEffect } from "react"
import type { AdDisplayLog } from "@/lib/types/ad-logs"
import MapsScript from "@/app/maps-script"
import { MapPin } from "lucide-react"

// Import Google Maps component dynamically to avoid SSR issues
const GoogleMapsWithNoSSR = dynamic(() => import("./google-maps-component"), {
  ssr: false,
  loading: () => (
    <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
    </div>
  ),
})

// Import Leaflet map as a fallback
const LeafletMapWithNoSSR = dynamic(() => import("./map-component"), {
  ssr: false,
  loading: () => (
    <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
    </div>
  ),
})

interface AdLogsMapProps {
  logs: AdDisplayLog[]
  isLoading?: boolean
}

export function AdLogsMap({ logs, isLoading = false }: AdLogsMapProps) {
  const [googleMapsError, setGoogleMapsError] = useState(false)
  const [apiKeyAvailable, setApiKeyAvailable] = useState(false)

  // Check if Google Maps API key is available
  useEffect(() => {
    // Check if the API key is available in the environment
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    setApiKeyAvailable(!!apiKey)

    // Set up an error listener
    const handleGoogleMapsError = () => {
      console.error("Google Maps failed to load (from event)")
      setGoogleMapsError(true)
    }

    window.addEventListener("google-maps-error", handleGoogleMapsError)

    // Check if Google Maps is already in an error state
    if (window.googleMapsLoadError) {
      setGoogleMapsError(true)
    }

    return () => {
      window.removeEventListener("google-maps-error", handleGoogleMapsError)
    }
  }, [])

  if (isLoading) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 dark:border-blue-400"></div>
      </div>
    )
  }

  if (logs.length === 0) {
    return (
      <div className="h-[500px] w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-lg">
        <p className="text-gray-500 dark:text-gray-400">No location data available for this campaign</p>
      </div>
    )
  }

  // If Google Maps API key is not available or there was an error, use Leaflet as fallback
  if (!apiKeyAvailable || googleMapsError) {
    return (
      <div className="relative">
        {!apiKeyAvailable && (
          <div className="absolute top-2 left-2 right-2 bg-yellow-50 text-yellow-800 px-4 py-2 rounded-md z-10 text-sm">
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-2" />
              <span>Using fallback map (Google Maps API key not configured)</span>
            </div>
          </div>
        )}
        <LeafletMapWithNoSSR logs={logs} />
      </div>
    )
  }

  return (
    <>
      <MapsScript />
      <GoogleMapsWithNoSSR logs={logs} />
    </>
  )
}

