import type { ReactNode } from "react"

interface StatCardProps {
  title: string
  value: string | number
  icon: ReactNode
  subtext?: string
}

// Update the StatCard component to use grey background and black text
export function StatCard({ title, value, icon, subtext }: StatCardProps) {
  return (
    <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-gray-800 dark:text-gray-200 font-medium mb-2">{title}</h3>
          <p className="text-3xl font-bold text-black dark:text-white">{value}</p>
          {subtext && <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{subtext}</p>}
        </div>
        <div className="text-gray-700 dark:text-gray-300">{icon}</div>
      </div>
    </div>
  )
}

