"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { MapPin, Calendar, Clock, User } from "lucide-react"

interface CampaignSpot {
  id: string
  timestamp: string
  location: {
    type: string
    coordinates: [number, number]
  }
  duration: number
  driver_id: string
  driver_name?: string
  vehicle_id?: string
  vehicle_plate?: string
}

interface CampaignSpotsProps {
  campaignId: string
}

export function CampaignSpots({ campaignId }: CampaignSpotsProps) {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [spots, setSpots] = useState<CampaignSpot[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user?.tokens.access) {
      fetchSpots()
    }
  }, [campaignId, user?.tokens.access])

  const fetchSpots = async () => {
    if (!user?.tokens.access) return

    try {
      setLoading(true)
      setError(null)

      const response = await fetch(`/api/proxy/campaigns/${campaignId}/spots`, {
        headers: {
          Authorization: `Bearer ${user.tokens.access}`,
        },
      })

      if (!response.ok) {
        throw new Error(`Failed to fetch spots: ${response.status}`)
      }

      const data = await response.json()
      setSpots(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error("Error fetching campaign spots:", err)
      setError(err instanceof Error ? err.message : "Failed to load campaign spots")
      setSpots([])
    } finally {
      setLoading(false)
    }
  }

  // Format date from ISO string
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    } catch (e) {
      return dateString
    }
  }

  // Format duration in minutes to hours and minutes
  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60

    if (hours > 0) {
      return `${hours}h ${mins}m`
    }
    return `${mins}m`
  }

  if (loading) {
    return (
      <div className="py-4 text-center text-gray-500 dark:text-gray-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 dark:border-blue-400 mx-auto mb-4"></div>
        <p>Loading campaign spots...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-md">
        {error}
      </div>
    )
  }

  if (spots.length === 0) {
    return <div className="text-center py-6 text-gray-500 dark:text-gray-400">No spots found for this campaign.</div>
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold mb-4">Campaign Logs</h3>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Date & Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Duration
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Driver
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Location
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {spots.map((spot) => (
              <tr key={spot.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
                    {formatDate(spot.timestamp)}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
                    {formatDuration(spot.duration)}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
                    {spot.driver_name || `Driver #${spot.driver_id}`}
                    {spot.vehicle_plate && <span className="ml-2 text-xs text-gray-500">({spot.vehicle_plate})</span>}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-gray-500 dark:text-gray-400" />
                    {spot.location?.coordinates ? (
                      <span>
                        {spot.location.coordinates[1].toFixed(6)}, {spot.location.coordinates[0].toFixed(6)}
                      </span>
                    ) : (
                      <span>Location not available</span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

