"use client"

import { useTheme } from "@/lib/theme-context"
import Image from "next/image"
import Link from "next/link"

interface LogoProps {
  className?: string
  size?: "small" | "medium" | "large"
}

export function Logo({ className = "", size = "medium" }: LogoProps) {
  const { theme } = useTheme()

  // Define sizes for different variants
  const sizes = {
    small: { width: 100, height: 30 },
    medium: { width: 150, height: 45 },
    large: { width: 200, height: 60 },
  }

  const { width, height } = sizes[size]

  return (
    <Link href="/dashboard" className={className}>
      <Image
        src={
          theme === "light"
            ? "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mobill-trans-black-300-3bkkztcc92v6L9YygHE6hloe4bMsMn.png" // Black logo for light theme
            : "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mobill-trans-white-300-k11ZKE54uaOR8sCvEgCAfzyQIJMRP9.png" // White logo for dark theme
        }
        alt="Mobill Logo"
        width={width}
        height={height}
        priority
        className="object-contain"
      />
    </Link>
  )
}

