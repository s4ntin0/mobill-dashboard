"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useLanguage } from "@/lib/language-context"
import { Upload, X, FileText, Image, Film } from "lucide-react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

interface AdUploadProps {
  onFileChange: (file: File | null, name: string, description: string) => void
  initialName?: string
  initialDescription?: string
  accept?: string
  maxSize?: number // in MB
}

export function AdUpload({
  onFileChange,
  initialName = "",
  initialDescription = "",
  accept = "image/*,video/*",
  maxSize = 10, // Default 10MB
}: AdUploadProps) {
  const { t } = useLanguage()
  const [file, setFile] = useState<File | null>(null)
  const [name, setName] = useState(initialName)
  const [description, setDescription] = useState(initialDescription)
  const [isDragging, setIsDragging] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null
    validateAndSetFile(selectedFile)
  }

  const validateAndSetFile = (selectedFile: File | null) => {
    setError(null)

    if (!selectedFile) {
      setFile(null)
      onFileChange(null, name, description)
      return
    }

    // Check file size
    const fileSizeInMB = selectedFile.size / (1024 * 1024)
    if (fileSizeInMB > maxSize) {
      setError(`File size exceeds ${maxSize}MB limit`)
      return
    }

    // Check file type
    if (!selectedFile.type.startsWith("image/") && !selectedFile.type.startsWith("video/")) {
      setError(`File type not supported. Please upload an image or video.`)
      return
    }

    // Set the file and notify parent
    setFile(selectedFile)
    onFileChange(selectedFile, name, description)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const droppedFile = e.dataTransfer.files?.[0] || null
    validateAndSetFile(droppedFile)
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value)
    onFileChange(file, e.target.value, description)
  }

  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(e.target.value)
    onFileChange(file, name, e.target.value)
  }

  const handleRemoveFile = () => {
    setFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
    onFileChange(null, name, description)
  }

  const getFileIcon = () => {
    if (!file) return null

    if (file.type.startsWith("image/")) {
      return <Image className="h-6 w-6 text-blue-500" />
    } else if (file.type.startsWith("video/")) {
      return <Film className="h-6 w-6 text-purple-500" />
    } else {
      return <FileText className="h-6 w-6 text-gray-500" />
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="ad-name" className="text-gray-800">
          {t("campaign.adName")}
        </Label>
        <Input
          id="ad-name"
          value={name}
          onChange={handleNameChange}
          className="bg-white text-black border-gray-300"
          placeholder={t("campaign.adNamePlaceholder")}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="ad-description" className="text-gray-800">
          {t("campaign.adDescription")}
        </Label>
        <Textarea
          id="ad-description"
          value={description}
          onChange={handleDescriptionChange}
          className="bg-white text-black border-gray-300"
          placeholder={t("campaign.adDescriptionPlaceholder")}
          rows={3}
        />
      </div>

      <div
        className={`border-2 border-dashed rounded-lg p-6 transition-colors ${
          isDragging ? "border-blue-500 bg-blue-50" : "border-gray-300"
        } ${error ? "border-red-500 bg-red-50" : ""}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept={accept} />

        <div className="flex flex-col items-center justify-center space-y-3 cursor-pointer">
          {file ? (
            <div className="flex items-center space-x-2">
              {getFileIcon()}
              <span className="text-sm font-medium text-gray-700">{file.name}</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation()
                  handleRemoveFile()
                }}
                className="p-1 rounded-full hover:bg-gray-200"
              >
                <X className="h-4 w-4 text-gray-500" />
              </button>
            </div>
          ) : (
            <>
              <Upload className="h-10 w-10 text-gray-400" />
              <p className="text-sm text-gray-500 text-center">{t("campaign.dragDrop")}</p>
              <p className="text-xs text-gray-400">{t("campaign.supportedFormats")}: JPG, PNG, GIF, MP4</p>
              <p className="text-xs text-gray-400">
                {t("campaign.maxSize")}: {maxSize}MB
              </p>
            </>
          )}
        </div>
      </div>

      {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
    </div>
  )
}

