/** @type {import('next').NextConfig} */
const nextConfig = {
  // Add specific configuration for API requests
  async rewrites() {
    return [
      {
        source: "/api/proxy/:path*",
        destination: "/api/proxy/:path*",
      },
    ]
  },
}

module.exports = nextConfig

