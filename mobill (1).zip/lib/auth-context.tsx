"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import type { User, AuthTokens } from "./types/auth"

interface AuthContextType {
  user: User | null
  login: (username: string, password: string, stayLoggedIn: boolean) => Promise<void>
  logout: () => Promise<void>
  loading: boolean
  error: string | null
  refreshToken: () => Promise<boolean>
  stayLoggedIn: boolean
  setStayLoggedIn: (value: boolean) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [stayLoggedIn, setStayLoggedIn] = useState<boolean>(false)
  const router = useRouter()

  useEffect(() => {
    // Check if user is already logged in
    const storedUser = localStorage.getItem("mobill_user")
    const storedStayLoggedIn = localStorage.getItem("mobill_stay_logged_in") === "true"

    setStayLoggedIn(storedStayLoggedIn)

    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser)
        setUser(parsedUser)

        // If stay logged in is enabled, try to refresh the token immediately
        if (storedStayLoggedIn) {
          refreshToken().catch((err) => {
            console.error("Auto token refresh failed:", err)
            // If token refresh fails, we'll keep the user logged in with the current token
            // The next API call will trigger another refresh attempt if needed
          })
        }
      } catch (e) {
        localStorage.removeItem("mobill_user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (username: string, password: string, stayLoggedIn = false) => {
    setLoading(true)
    setError(null)

    try {
      // Create FormData for x-www-form-urlencoded format
      const formData = new FormData()
      formData.append("username", username)
      formData.append("password", password)

      // Use our proxy API
      const response = await fetch("/api/proxy/login", {
        method: "POST",
        body: formData,
        // Include credentials to handle cookies
        credentials: "include",
      })

      if (!response.ok) {
        // Try to get error details if available
        try {
          const errorData = await response.json()
          throw new Error(errorData.message || "Login failed")
        } catch (parseError) {
          // If we can't parse the error response, try to get the text
          const errorText = await response.text().catch(() => "Unknown error")
          console.error("Login error response:", errorText.substring(0, 200))
          throw new Error("Login failed - please check your credentials")
        }
      }

      // Try to parse the response
      try {
        const tokens: AuthTokens = await response.json()

        if (!tokens.access || !tokens.refresh) {
          throw new Error("Invalid response from server")
        }

        // Create user object with tokens
        const userData: User = {
          id: username, // We might want to fetch actual user data here
          username,
          email: username, // We might want to fetch actual user data here
          tokens,
        }

        setUser(userData)
        localStorage.setItem("mobill_user", JSON.stringify(userData))

        // Save the stay logged in preference
        setStayLoggedIn(stayLoggedIn)
        localStorage.setItem("mobill_stay_logged_in", stayLoggedIn.toString())

        router.push("/dashboard")
      } catch (parseError) {
        console.error("Error parsing login response:", parseError)
        throw new Error("Invalid response format from server")
      }
    } catch (error) {
      console.error("Login error:", error)
      if (error instanceof Error) {
        setError(error.message)
      } else {
        setError("An unexpected error occurred. Please try again later.")
      }
    } finally {
      setLoading(false)
    }
  }

  const refreshToken = async (): Promise<boolean> => {
    if (!user?.tokens.refresh) {
      console.error("No refresh token available")
      return false
    }

    try {
      console.log("Attempting to refresh token...")

      // Use our proxy API for token refresh
      const response = await fetch("/api/proxy/refresh", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ refresh: user.tokens.refresh }),
        credentials: "include",
      })

      if (!response.ok) {
        console.error("Token refresh failed:", response.status, response.statusText)

        // If refresh fails and stay logged in is not enabled, log the user out
        if (!stayLoggedIn) {
          await logout()
        }
        return false
      }

      // Parse the new tokens
      const newTokens: AuthTokens = await response.json()

      if (!newTokens.access) {
        console.error("Invalid token refresh response")

        // If refresh fails and stay logged in is not enabled, log the user out
        if (!stayLoggedIn) {
          await logout()
        }
        return false
      }

      // Update the user object with new tokens
      const updatedUser: User = {
        ...user,
        tokens: newTokens,
      }

      setUser(updatedUser)
      localStorage.setItem("mobill_user", JSON.stringify(updatedUser))
      console.log("Token refreshed successfully")
      return true
    } catch (error) {
      console.error("Token refresh error:", error)

      // If refresh fails and stay logged in is not enabled, log the user out
      if (!stayLoggedIn) {
        await logout()
      }
      return false
    }
  }

  const logout = async () => {
    setLoading(true)

    try {
      if (user?.tokens.access) {
        // Use our proxy API
        await fetch("/api/proxy/logout", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${user.tokens.access}`,
          },
          credentials: "include",
        })
      }
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      setUser(null)
      localStorage.removeItem("mobill_user")
      localStorage.removeItem("mobill_stay_logged_in")
      setStayLoggedIn(false)
      router.push("/login")
      setLoading(false)
    }
  }

  // Function to update the stay logged in preference
  const updateStayLoggedIn = (value: boolean) => {
    setStayLoggedIn(value)
    localStorage.setItem("mobill_stay_logged_in", value.toString())
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        loading,
        error,
        refreshToken,
        stayLoggedIn,
        setStayLoggedIn: updateStayLoggedIn,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

