/**
 * Utility functions for authentication and API requests
 */

// Create a function that wraps fetch with token refresh capability
export async function fetchWithTokenRefresh(
  url: string,
  options: RequestInit & {
    authToken: string
    refreshCallback: () => Promise<boolean>
    headers?: HeadersInit
  },
): Promise<Response> {
  const { authToken, refreshCallback, ...fetchOptions } = options

  // First attempt with the current token
  const response = await fetch(url, {
    ...fetchOptions,
    headers: {
      ...fetchOptions.headers,
      Authorization: `Bearer ${authToken}`,
    },
  })

  // If we get a 401 Unauthorized, try to refresh the token and retry the request
  if (response.status === 401) {
    console.log("Received 401 response, attempting to refresh token...")

    // Try to refresh the token
    const refreshed = await refreshCallback()

    if (refreshed) {
      console.log("Token refreshed successfully, retrying request...")

      // Get the updated auth context after refresh
      // We need to get the new token from the auth context
      // This will be passed in by the component that uses this function

      // Retry the request with the new token
      return fetch(url, {
        ...fetchOptions,
        headers: {
          ...fetchOptions.headers,
          Authorization: `Bearer ${authToken}`, // The component will pass the new token
        },
      })
    }

    // If refresh failed, return the original 401 response
    console.log("Token refresh failed, returning original 401 response")
    return response
  }

  // For any other response, return it directly
  return response
}

