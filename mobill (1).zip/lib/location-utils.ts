// Convert latitude and longitude to GeoJSON Point format
export function formatPoint(
  longitude: number,
  latitude: number,
): {
  type: string
  coordinates: [number, number]
} {
  return {
    type: "Point",
    coordinates: [longitude, latitude],
  }
}

// Parse GeoJSON Point format to latitude and longitude
export function parsePoint(point: any): { longitude: number; latitude: number } | null {
  try {
    // Handle GeoJSON object format
    if (point && typeof point === "object" && point.type === "Point" && Array.isArray(point.coordinates)) {
      return {
        longitude: point.coordinates[0],
        latitude: point.coordinates[1],
      }
    }

    // Handle legacy string format (POINT(lon, lat))
    if (typeof point === "string") {
      const match = point.match(/POINT\s*$$\s*([+-]?\d+(\.\d+)?)\s*,\s*([+-]?\d+(\.\d+)?)\s*$$/)
      if (match) {
        return {
          longitude: Number.parseFloat(match[1]),
          latitude: Number.parseFloat(match[3]),
        }
      }
    }

    return null
  } catch (error) {
    console.error("Error parsing point:", error)
    return null
  }
}

// Safely format a location point for display
export function formatPointForDisplay(point: any): string {
  if (!point) {
    return "Location not available"
  }

  try {
    // Handle GeoJSON object format
    if (typeof point === "object" && point.type === "Point" && Array.isArray(point.coordinates)) {
      return `${point.coordinates[0]}, ${point.coordinates[1]}`
    }

    // Handle legacy string format
    if (typeof point === "string") {
      return point.replace("POINT(", "").replace(")", "")
    }

    return "Location format not recognized"
  } catch (error) {
    console.error("Error formatting point for display:", error)
    return "Location not available"
  }
}

