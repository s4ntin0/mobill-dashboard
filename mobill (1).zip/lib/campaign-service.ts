"use client"
import { fetchWithTokenRefresh } from "@/lib/auth-service"

export interface Ad {
  id: string
  name: string
  imageUrl: string
  content_type: string
}

export interface Market {
  id: string
  name: string
  country: string
  city: string
  countryCode: string
}

export interface Campaign {
  id: string
  name: string
  description: string
  start: string
  duration: number
  ad: number
  location: any
  radius: number | null
  market: number
  daily_budget: string
  show_on_weekends: boolean
  road_type: string
  traffic_density: string
  impressions?: number
  minutes?: number
  budgetSpent?: number
  status?: string
  active?: boolean
}

// Add this interface to the existing interfaces
export interface CampaignStats {
  impressions: number
  active_campaigns: number
  this_month_hours: number
  today_hours: number
}

export interface RoadType {
  id: string
  name: string
}

export interface TrafficDensity {
  id: string
  name: string
}

export interface CampaignSummary {
  totalImpressions: number
  totalMinutes: number
  totalAssigned: number
  budgetSpent: number
  budgetRemaining: number
  activeCampaigns: Campaign[]
}

export interface CampaignSpot {
  id: string
  timestamp: string
  location: {
    type: string
    coordinates: [number, number]
  }
  duration: number
  driver_id: string
  driver_name?: string
  vehicle_id?: string
  vehicle_plate?: string
}

// Mock data for fallback
const fallbackAds: Ad[] = [
  {
    id: "1",
    name: "Default Ad",
    imageUrl: "",
    content_type: "image",
  },
]
const fallbackMarkets: Market[] = []

// Fetch ads from API with fallback to mock data
export async function getAds(token: string): Promise<Ad[]> {
  try {
    console.log("Fetching ads from API...")
    const response = await fetch("/api/proxy/ads", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    // If response is not OK, log the error and use fallback data
    if (!response.ok) {
      console.warn(`Failed to fetch ads: ${response.status} ${response.statusText}`)
      return fallbackAds
    }

    // Parse the response
    try {
      const data = await response.json()
      return Array.isArray(data) ? data : fallbackAds
    } catch (parseError) {
      console.error("Error parsing ads response:", parseError)
      return fallbackAds
    }
  } catch (error) {
    console.error("Error fetching ads:", error)
    return fallbackAds
  }
}

// Fetch markets from API with fallback to mock data
export async function getMarkets(token: string): Promise<Market[]> {
  try {
    console.log("Fetching markets from API...")
    const response = await fetch("/api/proxy/markets", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    // If response is not OK, log the error and use fallback data
    if (!response.ok) {
      console.warn(`Failed to fetch markets: ${response.status} ${response.statusText}`)
      return fallbackMarkets
    }

    // Parse the response
    try {
      const data = await response.json()
      return Array.isArray(data) ? data : fallbackMarkets
    } catch (parseError) {
      console.error("Error parsing markets response:", parseError)
      return fallbackMarkets
    }
  } catch (error) {
    console.error("Error fetching markets:", error)
    return fallbackMarkets
  }
}

// Update the getCampaigns function to use token refresh
export async function getCampaigns(token: string, refreshToken: () => Promise<string>): Promise<Campaign[]> {
  try {
    // Add a timestamp to prevent caching
    const timestamp = new Date().getTime()

    // Use the fetchWithTokenRefresh utility
    const response = await fetchWithTokenRefresh(`/api/proxy/campaigns?_t=${timestamp}&user_campaigns_only=true`, {
      authToken: token,
      refreshCallback: refreshToken,
      headers: {
        Accept: "application/json",
      },
    })

    if (!response.ok) {
      console.warn(`Failed to fetch campaigns: ${response.status} ${response.statusText}`)
      throw new Error(`Failed to fetch campaigns: ${response.status}`)
    }

    try {
      const data = await response.json()

      // Ensure we have an array of campaigns
      if (Array.isArray(data)) {
        console.log(`Fetched ${data.length} campaigns for the current user`)
        return data
      } else {
        console.warn("API did not return an array of campaigns:", data)
        return []
      }
    } catch (parseError) {
      console.error("Error parsing campaigns response:", parseError)
      return []
    }
  } catch (error) {
    console.error("Error fetching campaigns:", error)
    throw error
  }
}

export async function getCampaignById(id: string, token: string): Promise<Campaign> {
  try {
    const response = await fetch(`/api/proxy/campaigns/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      console.warn(`Failed to fetch campaign details: ${response.status} ${response.statusText}`)
      throw new Error("Failed to fetch campaign details")
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching campaign details:", error)
    throw error
  }
}

// Add this new function to fetch campaign spots
export async function getCampaignSpots(id: string, token: string): Promise<CampaignSpot[]> {
  try {
    const response = await fetch(`/api/proxy/campaigns/${id}/spots`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      console.warn(`Failed to fetch campaign spots: ${response.status} ${response.statusText}`)
      throw new Error("Failed to fetch campaign spots")
    }

    const data = await response.json()
    return Array.isArray(data) ? data : []
  } catch (error) {
    console.error("Error fetching campaign spots:", error)
    throw error
  }
}

export async function createCampaign(campaign: Omit<Campaign, "id">, token: string): Promise<Campaign> {
  try {
    console.log("Creating campaign with data:", campaign)

    const response = await fetch("/api/proxy/campaigns", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(campaign),
    })

    if (!response.ok) {
      console.warn(`Failed to create campaign: ${response.status} ${response.statusText}`)

      try {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to create campaign")
      } catch (parseError) {
        throw new Error("Failed to create campaign")
      }
    }

    return await response.json()
  } catch (error) {
    console.error("Error creating campaign:", error)
    throw error
  }
}

// Updated to handle partial updates better by fetching the campaign first if needed
export async function updateCampaign(id: string, campaignUpdates: Partial<Campaign>, token: string): Promise<Campaign> {
  try {
    console.log(`Updating campaign ${id} with data:`, campaignUpdates)

    // Check if we have all required fields
    const requiredFields = ["description", "daily_budget", "duration", "market", "ad"]
    const hasAllRequiredFields = requiredFields.every((field) => field in campaignUpdates)

    // If we don't have all required fields, fetch the campaign first
    let completeUpdates = campaignUpdates
    if (!hasAllRequiredFields) {
      console.log("Not all required fields provided, fetching current campaign data first")
      const currentCampaign = await getCampaignById(id, token)

      // Merge the current campaign with the updates
      completeUpdates = {
        ...currentCampaign,
        ...campaignUpdates,
      }

      console.log("Complete update data:", completeUpdates)
    }

    // Make sure the URL doesn't have a trailing slash to match the API proxy route
    const url = `/api/proxy/campaigns/${id}`
    console.log(`Sending PUT request to: ${url}`)

    const response = await fetch(url, {
      method: "PUT", // Changed from POST to PUT
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(completeUpdates),
    })

    // Log the response status
    console.log(`Update campaign response status: ${response.status}`)

    if (!response.ok) {
      // Try to get the response text for better error diagnostics
      const errorText = await response.text().catch(() => "Could not read error response")
      console.error(`Failed to update campaign: ${response.status} ${response.statusText}`)
      console.error(`Error response: ${errorText.substring(0, 500)}`)

      try {
        // Try to parse as JSON if possible
        const errorData = JSON.parse(errorText)
        throw new Error(errorData.message || errorData.detail || "Failed to update campaign")
      } catch (parseError) {
        // If parsing fails, use the text response in the error
        throw new Error(`Failed to update campaign: ${errorText.substring(0, 100)}`)
      }
    }

    // Try to parse the successful response
    try {
      const data = await response.json()
      return data
    } catch (parseError) {
      console.error("Error parsing update response:", parseError)
      throw new Error("Failed to parse update response")
    }
  } catch (error) {
    console.error("Error updating campaign:", error)
    if (error instanceof Error) {
      throw error
    } else {
      throw new Error("Unknown error updating campaign")
    }
  }
}

// Make sure this function is properly exported
export function getCampaignSummary(campaigns: Campaign[]): CampaignSummary {
  const totalImpressions = campaigns.reduce((sum, campaign) => sum + (campaign.impressions || 0), 0)
  const totalMinutes = campaigns.reduce((sum, campaign) => sum + (campaign.minutes || 0), 0)
  const totalAssigned = campaigns.length
  const budgetSpent = campaigns.reduce((sum, campaign) => sum + (campaign.budgetSpent || 0), 0)
  const budgetRemaining = 100000 - budgetSpent // Assuming a total budget of 100000
  const activeCampaigns = campaigns.filter((campaign) => campaign.active)

  return {
    totalImpressions,
    totalMinutes,
    totalAssigned,
    budgetSpent,
    budgetRemaining,
    activeCampaigns,
  }
}

export async function getRoadTypes(): Promise<RoadType[]> {
  return Promise.resolve([
    { id: "any", name: "Any" }, // Changed from "Any" to "any"
    { id: "major", name: "Major" }, // Changed from "Highway" to "major"
    { id: "secondary", name: "Secondary" }, // Changed from "CityStreet" to "secondary"
    { id: "local", name: "Local" }, // Changed from "RuralRoad" to "local"
  ])
}

export async function getTrafficDensities(): Promise<TrafficDensity[]> {
  return Promise.resolve([
    { id: "any", name: "Any" }, // Changed from "Any" to "any"
    { id: "heavy", name: "Heavy" }, // Changed from "High" to "heavy"
    { id: "medium", name: "Medium" },
    { id: "low", name: "Low" },
  ])
}

// Add this function to handle ad uploads
export async function uploadAd(file: File, name: string, description: string, token: string): Promise<Ad> {
  try {
    const formData = new FormData()

    // The API expects the image file in a field named 'image'
    formData.append("image", file)
    formData.append("description", description)
    formData.append("text", name) // Using text field for the name
    formData.append("type", file.type.startsWith("image/") ? "image" : "text")

    const response = await fetch("/api/proxy/ads", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    })

    if (!response.ok) {
      console.warn(`Failed to upload ad: ${response.status} ${response.statusText}`)

      try {
        const errorData = await response.json()
        throw new Error(errorData.message || "Failed to upload ad")
      } catch (parseError) {
        throw new Error("Failed to upload ad")
      }
    }

    return await response.json()
  } catch (error) {
    console.error("Error uploading ad:", error)
    throw error
  }
}

// Update the getCampaignStats function to use the correct endpoint
export async function getCampaignStats(token: string): Promise<CampaignStats> {
  try {
    const response = await fetch("/api/proxy/campaign-stats", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      console.warn(`Failed to fetch campaign stats: ${response.status} ${response.statusText}`)
      // Return default stats if the API fails
      return {
        impressions: 0,
        active_campaigns: 0,
        this_month_hours: 0,
        today_hours: 0,
      }
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching campaign stats:", error)
    // Return default stats if there's an error
    return {
      impressions: 0,
      active_campaigns: 0,
      this_month_hours: 0,
      today_hours: 0,
    }
  }
}

