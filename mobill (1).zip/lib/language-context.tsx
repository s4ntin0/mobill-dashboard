"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Language = "en" | "es"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

// Translations
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Auth
    "login.title": "Log in",
    "login.username": "Username",
    "login.password": "Password",
    "login.button": "Log in",
    "login.noAccount": "I don't have an account",
    "login.signup": "Sign up",
    "login.language": "Language",
    "login.stayLoggedIn": "Stay logged in",

    // Dashboard
    "dashboard.title": "Dashboard",
    "dashboard.overview": "Overview of your campaign performance",
    "dashboard.createCampaign": "Create Campaign",
    "dashboard.totalImpressions": "Total Impressions",
    "dashboard.totalMinutes": "Total Minutes",
    "dashboard.totalAssigned": "Total Assigned",
    "dashboard.budgetSpent": "Budget Spent",
    "dashboard.remaining": "remaining",
    "dashboard.activeCampaigns": "Active Campaigns",
    "dashboard.noCampaigns": "No campaigns found",
    "dashboard.noActiveCampaigns": "No active campaigns found",
    "dashboard.campaignStats": "Campaign Statistics",
    "dashboard.campaignSummary": "Campaign Summary",
    "dashboard.activeCampaignsCount": "Active Campaigns",
    "dashboard.thisMonthHours": "Hours This Month",
    "dashboard.todayHours": "Hours Today",
    "dashboard.campaigns": "Campaigns",
    "dashboard.showAllCampaigns": "Show all campaigns",

    // Campaign Form
    "campaign.create": "Create New Campaign",
    "campaign.edit": "Edit Campaign",
    "campaign.description": "Make changes to your campaign settings below.",
    "campaign.basicInfo": "Basic Information",
    "campaign.campaignDescription": "Campaign Description",
    "campaign.startDate": "Start Date",
    "campaign.duration": "Duration (Days)",
    "campaign.dailyBudget": "Daily Budget",
    "campaign.contentMarket": "Content & Market",
    "campaign.advertisement": "Advertisement",
    "campaign.market": "Market",
    "campaign.locationTargeting": "Location Targeting",
    "campaign.enableLocation": "Enable location targeting",
    "campaign.disableLocation": "Disable location targeting",
    "campaign.longitude": "Longitude",
    "campaign.latitude": "Latitude",
    "campaign.radius": "Radius (meters)",
    "campaign.locationDisabled": "Location targeting is disabled. Campaign will be shown across the selected market.",
    "campaign.targetingOptions": "Targeting Options",
    "campaign.roadType": "Road Type",
    "campaign.trafficDensity": "Traffic Density",
    "campaign.showWeekends": "Show on Weekends",
    "campaign.cancel": "Cancel",
    "campaign.update": "Update Campaign",
    "campaign.create": "Create Campaign",
    "campaign.contentUpload": "Content Upload",
    "campaign.uploadDescription": "Upload images, videos, or text for your campaign",
    "campaign.fileType": "File Type",
    "campaign.contentDescription": "Content Description",
    "campaign.uploadFile": "Upload File",
    "campaign.dragDrop": "Drag and drop files here, or click to select files",
    "campaign.active": "Active",
    "campaign.inactive": "Inactive",
    "campaign.activate": "Activate Campaign",
    "campaign.deactivate": "Deactivate Campaign",
    "campaign.toggleError": "Failed to update campaign status",

    // General
    "general.loading": "Loading...",
    "general.error": "An error occurred. Please try again.",
    "general.save": "Save",
    "general.cancel": "Cancel",
    "general.delete": "Delete",
    "general.edit": "Edit",
    "general.back": "Back",
    "general.refresh": "Refresh",
    "general.logout": "Logout",

    // Ad Upload
    "campaign.adUpload": "Ad Upload",
    "campaign.adUploadDescription": "Upload images or videos for your campaign",
    "campaign.adName": "Ad Name",
    "campaign.adNamePlaceholder": "Enter a name for this ad",
    "campaign.adDescription": "Ad Description",
    "campaign.adDescriptionPlaceholder": "Describe your ad content",
    "campaign.dragDrop": "Drag and drop files here, or click to select files",
    "campaign.supportedFormats": "Supported formats",
    "campaign.maxSize": "Max size",
    "campaign.uploadingAd": "Uploading ad",

    // Additional Translations
    radius: "Radius",
    starts: "Starts",
    duration: "Duration",
    daily_budget: "Daily Budget",
    spent: "Spent",
    road_type: "Road Type",
    traffic_density: "Traffic Density",
    impressions: "Impressions",
    minutes: "Minutes",

    // Billing
    "dashboard.billing": "Billing",
    "billing.title": "Billing & Payment",
    "billing.paymentMethod": "Payment Method",
    "billing.updatePayment": "Update Payment Method",
    "billing.paymentHistory": "Payment History",
    "billing.noPayments": "No payment history available",
    "billing.date": "Date",
    "billing.amount": "Amount",
    "billing.status": "Status",
    "billing.description": "Description",
    "billing.cardDetails": "Card Details",
    "billing.save": "Save Payment Method",
    "billing.processing": "Processing...",

    // Signup
    "signup.title": "Advertiser Registration",
    "signup.username": "Username",
    "signup.email": "Email",
    "signup.password": "Password",
    "signup.confirmPassword": "Confirm Password",
    "signup.companyName": "Company Name",
    "signup.contactName": "Contact Name",
    "signup.contactPhone": "Contact Phone Number",
    "signup.register": "Register",
    "signup.alreadyHaveAccount": "Already have an account?",
    "signup.login": "Log in",
    "signup.accountInfo": "Account Information",
    "signup.companyInfo": "Company Information",
    "signup.success": "Registration Successful!",
    "signup.successMessage": "Your account has been created. You will be redirected to the login page shortly.",
    "signup.passwordsDoNotMatch": "Passwords do not match",
  },
  es: {
    // Auth
    "login.title": "Iniciar sesión",
    "login.username": "Nombre de usuario",
    "login.password": "Contraseña",
    "login.button": "Iniciar sesión",
    "login.noAccount": "No tengo una cuenta",
    "login.signup": "Registrarse",
    "login.language": "Idioma",
    "login.stayLoggedIn": "Mantener sesión iniciada",

    // Dashboard
    "dashboard.title": "Panel de control",
    "dashboard.overview": "Resumen del rendimiento de su campaña",
    "dashboard.createCampaign": "Crear campaña",
    "dashboard.totalImpressions": "Impresiones totales",
    "dashboard.totalMinutes": "Minutos totales",
    "dashboard.totalAssigned": "Total asignado",
    "dashboard.budgetSpent": "Presupuesto gastado",
    "dashboard.remaining": "restante",
    "dashboard.activeCampaigns": "Campañas activas",
    "dashboard.noCampaigns": "No se encontraron campañas",
    "dashboard.noActiveCampaigns": "No se encontraron campañas activas",
    "dashboard.campaignStats": "Estadísticas de Campaña",
    "dashboard.campaignSummary": "Resumen de Campaña",
    "dashboard.activeCampaignsCount": "Campañas Activas",
    "dashboard.thisMonthHours": "Horas Este Mes",
    "dashboard.todayHours": "Horas Hoy",
    "dashboard.campaigns": "Campañas",
    "dashboard.showAllCampaigns": "Mostrar todas las campañas",

    // Campaign Form
    "campaign.create": "Crear nueva campaña",
    "campaign.edit": "Editar campaña",
    "campaign.description": "Realice cambios en la configuración de su campaña a continuación.",
    "campaign.basicInfo": "Información básica",
    "campaign.campaignDescription": "Descripción de la campaña",
    "campaign.startDate": "Fecha de inicio",
    "campaign.duration": "Duración (días)",
    "campaign.dailyBudget": "Presupuesto diario",
    "campaign.contentMarket": "Contenido y mercado",
    "campaign.advertisement": "Anuncio",
    "campaign.market": "Mercado",
    "campaign.locationTargeting": "Segmentación por ubicación",
    "campaign.enableLocation": "Habilitar segmentación por ubicación",
    "campaign.disableLocation": "Deshabilitar segmentación por ubicación",
    "campaign.longitude": "Longitud",
    "campaign.latitude": "Latitud",
    "campaign.radius": "Radio (metros)",
    "campaign.locationDisabled":
      "La segmentación por ubicación está deshabilitada. La campaña se mostrará en todo el mercado seleccionado.",
    "campaign.targetingOptions": "Opciones de segmentación",
    "campaign.roadType": "Tipo de carretera",
    "campaign.trafficDensity": "Densidad de tráfico",
    "campaign.showWeekends": "Mostrar en fines de semana",
    "campaign.cancel": "Cancelar",
    "campaign.update": "Actualizar campaña",
    "campaign.create": "Crear campaña",
    "campaign.contentUpload": "Carga de contenido",
    "campaign.uploadDescription": "Sube imágenes, videos o texto para tu campaña",
    "campaign.fileType": "Tipo de archivo",
    "campaign.contentDescription": "Descripción del contenido",
    "campaign.uploadFile": "Subir archivo",
    "campaign.dragDrop": "Arrastra y suelta archivos aquí, o haz clic para seleccionar archivos",
    "campaign.active": "Activa",
    "campaign.inactive": "Inactiva",
    "campaign.activate": "Activar Campaña",
    "campaign.deactivate": "Desactivar Campaña",
    "campaign.toggleError": "Error al actualizar el estado de la campaña",

    // General
    "general.loading": "Cargando...",
    "general.error": "Se produjo un error. Por favor, inténtelo de nuevo.",
    "general.save": "Guardar",
    "general.cancel": "Cancelar",
    "general.delete": "Eliminar",
    "general.edit": "Editar",
    "general.back": "Atrás",
    "general.refresh": "Actualizar",
    "general.logout": "Cerrar sesión",

    // Ad Upload
    "campaign.adUpload": "Carga de anuncio",
    "campaign.adUploadDescription": "Sube imágenes o videos para tu campaña",
    "campaign.adName": "Nombre del anuncio",
    "campaign.adNamePlaceholder": "Ingresa un nombre para este anuncio",
    "campaign.adDescription": "Descripción del anuncio",
    "campaign.adDescriptionPlaceholder": "Describe el contenido de tu anuncio",
    "campaign.dragDrop": "Arrastra y suelta archivos aquí, o haz clic para seleccionar archivos",
    "campaign.supportedFormats": "Formatos soportados",
    "campaign.maxSize": "Tamaño máximo",
    "campaign.uploadingAd": "Subiendo anuncio",

    // Additional Translations
    radius: "Radio",
    starts: "Comienza",
    duration: "Duración",
    daily_budget: "Presupuesto diario",
    spent: "Gastado",
    road_type: "Tipo de carretera",
    traffic_density: "Densidad de tráfico",
    impressions: "Impresiones",
    minutes: "Minutos",

    // Billing
    "dashboard.billing": "Facturación",
    "billing.title": "Facturación y Pago",
    "billing.paymentMethod": "Método de Pago",
    "billing.updatePayment": "Actualizar Método de Pago",
    "billing.paymentHistory": "Historial de Pagos",
    "billing.noPayments": "No hay historial de pagos disponible",
    "billing.date": "Fecha",
    "billing.amount": "Cantidad",
    "billing.status": "Estado",
    "billing.description": "Descripción",
    "billing.cardDetails": "Detalles de la Tarjeta",
    "billing.save": "Guardar Método de Pago",
    "billing.processing": "Procesando...",

    // Signup
    "signup.title": "Registro de Anunciante",
    "signup.username": "Nombre de usuario",
    "signup.email": "Correo electrónico",
    "signup.password": "Contraseña",
    "signup.confirmPassword": "Confirmar contraseña",
    "signup.companyName": "Nombre de la empresa",
    "signup.contactName": "Nombre de contacto",
    "signup.contactPhone": "Número de teléfono de contacto",
    "signup.register": "Registrarse",
    "signup.alreadyHaveAccount": "¿Ya tienes una cuenta?",
    "signup.login": "Iniciar sesión",
    "signup.accountInfo": "Información de la cuenta",
    "signup.companyInfo": "Información de la empresa",
    "signup.success": "¡Registro exitoso!",
    "signup.successMessage": "Tu cuenta ha sido creada. Serás redirigido a la página de inicio de sesión en breve.",
    "signup.passwordsDoNotMatch": "Las contraseñas no coinciden",
  },
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en")

  // Load language preference from localStorage on initial render
  useEffect(() => {
    const savedLanguage = localStorage.getItem("mobill_language") as Language
    if (savedLanguage && (savedLanguage === "en" || savedLanguage === "es")) {
      setLanguageState(savedLanguage)
    }
  }, [])

  // Save language preference to localStorage when it changes
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("mobill_language", newLanguage)
  }

  // Translation function
  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

