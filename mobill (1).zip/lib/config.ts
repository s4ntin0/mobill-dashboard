// Environment configuration for the application

// API configuration
export const API_CONFIG = {
  // Base URL for the API - use environment variable or fallback to the hardcoded value
  baseUrl: process.env.NEXT_PUBLIC_API_BASE_URL || "https://api.mobill.com",

  // API version path
  apiPath: "/api/v1",

  // Endpoints
  endpoints: {
    // Auth endpoints
    auth: {
      login: "/users/login",
      logout: "/users/logout",
      refresh: "/users/refresh",
      register: "/users/register/advertiser",
    },

    // Core endpoints
    core: {
      campaigns: "/core/campaigns/",
      ads: "/core/ads/",
      markets: "/core/markets/",
      campaign_stats: "/core/campaign-stats", // Updated to use hyphen
    },

    // User endpoints
    user: {
      payment_history: "/stripe/payment-history", // Updated endpoint
    },

    // Stripe endpoints
    stripe: {
      payment_history: "/stripe/payment-history",
      create_customer_session: "/stripe/create-customer-session",
    },
  },

  // Request timeout in milliseconds
  timeout: 30000,
}

// Application configuration
export const APP_CONFIG = {
  // Application name
  appName: "Mobill",

  // Application description
  appDescription: "Mobile billboarding campaign management platform",

  // Default campaign budget
  defaultDailyBudget: "100.00",

  // Default campaign duration in days
  defaultCampaignDuration: 7,

  // Default location radius in meters
  defaultLocationRadius: 1000,
}

// Feature flags
export const FEATURES = {
  // Enable/disable location targeting
  enableLocationTargeting: true,

  // Enable/disable weekend targeting
  enableWeekendTargeting: true,
}

