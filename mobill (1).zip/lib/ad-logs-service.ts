import type { AdDisplayLog, AdDisplayLogsResponse } from "./types/ad-logs"

export async function getAdDisplayLogs(
  campaignId: string,
  token: string,
  page = 1,
  pageSize = 100,
): Promise<AdDisplayLogsResponse> {
  try {
    const response = await fetch(`/api/proxy/campaigns/${campaignId}/ad-logs?page=${page}&page_size=${pageSize}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch ad logs: ${response.status}`)
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error("Error fetching ad display logs:", error)
    throw error
  }
}

// For demo purposes, generate some sample logs with location data
export function generateSampleAdLogs(campaignId: string, count = 20): AdDisplayLog[] {
  const logs: AdDisplayLog[] = []

  // Generate logs around Madrid, Spain
  const centerLat = 40.416775
  const centerLng = -3.70379

  // Define some road types and traffic densities for variety
  const roadTypes = ["Highway", "Local", "Secondary", "Urban"]
  const trafficDensities = [1, 2, 3] // Low, Medium, High

  // Create a more realistic distribution of points
  // Define a few "routes" as arrays of coordinate pairs
  const routes = [
    // Main highway north-south
    [
      [centerLat - 0.05, centerLng],
      [centerLat - 0.03, centerLng + 0.01],
      [centerLat - 0.01, centerLng + 0.02],
      [centerLat + 0.01, centerLng + 0.02],
      [centerLat + 0.03, centerLng + 0.01],
      [centerLat + 0.05, centerLng],
    ],
    // East-west route
    [
      [centerLat, centerLng - 0.05],
      [centerLat + 0.01, centerLng - 0.03],
      [centerLat + 0.01, centerLng - 0.01],
      [centerLat + 0.01, centerLng + 0.01],
      [centerLat, centerLng + 0.03],
      [centerLat - 0.01, centerLng + 0.05],
    ],
    // Circular route
    [
      [centerLat + 0.02, centerLng + 0.02],
      [centerLat + 0.02, centerLng - 0.02],
      [centerLat - 0.02, centerLng - 0.02],
      [centerLat - 0.02, centerLng + 0.02],
      [centerLat + 0.02, centerLng + 0.02],
    ],
  ]

  // Distribute points along routes
  for (let i = 0; i < count; i++) {
    // Select a route
    const routeIndex = i % routes.length
    const route = routes[routeIndex]

    // Select a segment along the route
    const segmentIndex = Math.floor(Math.random() * (route.length - 1))
    const [startLat, startLng] = route[segmentIndex]
    const [endLat, endLng] = route[segmentIndex + 1]

    // Calculate a position along the segment (0-1)
    const position = Math.random()

    // Interpolate between start and end points
    const lat = startLat + (endLat - startLat) * position
    const lng = startLng + (endLng - startLng) * position

    // Add some small random variation
    const jitter = 0.002 // About 200m
    const finalLat = lat + (Math.random() - 0.5) * jitter
    const finalLng = lng + (Math.random() - 0.5) * jitter

    // Create timestamp with decreasing times (newest first)
    const date = new Date()
    date.setMinutes(date.getMinutes() - i * 15) // 15 minute intervals

    // Randomize some attributes
    const roadType = roadTypes[Math.floor(Math.random() * roadTypes.length)]
    const trafficDensity = trafficDensities[Math.floor(Math.random() * trafficDensities.length)]
    const speed = 20 + Math.floor(Math.random() * 60) // 20-80 km/h

    logs.push({
      id: `${2234 - i}`,
      user_id: "4",
      display_id: `${1000 + i}`,
      campaign_id: campaignId,
      price: 0.05 + Math.random() * 0.1, // 0.05-0.15
      vehicle_speed: speed,
      traffic_density: trafficDensity,
      road_type: roadType,
      timestamp: date.toISOString(),
      current_speed: speed,
      free_flow_speed: speed + 10,
      latitude: finalLat,
      longitude: finalLng,
      location: {
        type: "Point",
        coordinates: [finalLng, finalLat], // GeoJSON uses [longitude, latitude]
      },
    })
  }

  return logs
}

