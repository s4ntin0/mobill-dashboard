interface PaymentMethodStatus {
  payment_method_attached: boolean
  loading: boolean
  error: string | null
}

/**
 * Checks if the user has a payment method attached
 */
export async function checkPaymentMethodStatus(token: string): Promise<PaymentMethodStatus> {
  try {
    console.log("Checking payment method status...")

    const response = await fetch("/api/proxy/payment-history", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      console.error(`Failed to check payment method status: ${response.status}`)
      return {
        payment_method_attached: true, // Default to true to allow campaign creation
        loading: false,
        error: `Failed to check payment method status: ${response.status}`,
      }
    }

    const data = await response.json()

    // The API returns payment_method_attached field
    // If the field is missing, default to true to allow campaign creation
    const hasPaymentMethod = data.payment_method_attached !== undefined ? !!data.payment_method_attached : true

    console.log(`Payment method attached: ${hasPaymentMethod ? "Yes" : "No"}`)

    return {
      payment_method_attached: hasPaymentMethod,
      loading: false,
      error: null,
    }
  } catch (error) {
    console.error("Error checking payment method status:", error)
    return {
      payment_method_attached: true, // Default to true on error to allow campaign creation
      loading: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

