export interface PaymentRecord {
  id: string
  amount: number
  currency: string
  status: string
  created: number
  payment_method_type: string
  receipt_url: string
  description: string
  metadata: Record<string, any>
}

export interface PaymentHistoryResponse {
  data: PaymentRecord[]
  has_more: boolean
  next_page: string | null
  total_count: number
}

