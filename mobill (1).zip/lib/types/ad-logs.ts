export interface AdDisplayLog {
  id: string
  user_id: string
  display_id: string
  campaign_id: string
  price: number
  vehicle_speed: number
  traffic_density: number
  road_type: string
  timestamp: string
  current_speed: number
  free_flow_speed: number
  // Location data (may need to be added to the API response)
  latitude?: number
  longitude?: number
  location?: {
    type: string
    coordinates: [number, number] // [longitude, latitude]
  }
}

export interface AdDisplayLogsResponse {
  data: AdDisplayLog[]
  total_count: number
  page: number
  page_size: number
}

