// Update the Ad interface to match the API response
export interface Ad {
  id: number
  description: string
  type: "text" | "image"
  text: string
  image_url: string | null
  image: string | null
}

export interface AuthTokens {
  refresh: string
  access: string
}

export interface User {
  id: string
  username: string
  email: string
  tokens: AuthTokens
}

