interface Window {
  google?: {
    maps?: any
  }
}

