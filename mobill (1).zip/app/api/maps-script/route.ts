import { NextResponse } from "next/server"

export async function GET() {
  // Use the provided API key directly
  const apiKey = "AIzaSyCiO-QxdVxTrdWmWnzAOnHEhWdugGJLE_k"

  // Generate the Google Maps script URL
  const scriptUrl = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=visualization,marker&v=weekly`

  // Redirect to the script URL
  return NextResponse.redirect(scriptUrl)
}

