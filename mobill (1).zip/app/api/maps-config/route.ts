import { NextResponse } from "next/server"

export async function GET() {
  // Use the specific Map ID provided by the user
  const mapId = "467c6dfd66cd4cf8"

  // Use the provided API key directly
  const apiKey = "AIzaSyCiO-QxdVxTrdWmWnzAOnHEhWdugGJLE_k"

  // Return the configuration with the specific Map ID
  return NextResponse.json({
    mapId: mapId,
    hasApiKey: true,
    apiKey: apiKey,
  })
}

