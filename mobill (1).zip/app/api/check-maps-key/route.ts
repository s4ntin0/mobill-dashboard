import { NextResponse } from "next/server"

export async function GET() {
  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""

  if (!apiKey) {
    return NextResponse.json({
      valid: false,
      message: "Google Maps API key is not defined",
    })
  }

  try {
    // Make a simple request to the Google Maps API to check if the key is valid
    const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=Madrid&key=${apiKey}`)

    const data = await response.json()

    if (data.error_message) {
      return NextResponse.json({
        valid: false,
        message: data.error_message,
      })
    }

    return NextResponse.json({
      valid: true,
      message: "Google Maps API key is valid",
    })
  } catch (error) {
    return NextResponse.json({
      valid: false,
      message: "Failed to validate Google Maps API key",
    })
  }
}

