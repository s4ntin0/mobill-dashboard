import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

// Initialize Stripe with your secret key
// In a real app, this would come from an environment variable
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_your_key", {
  apiVersion: "2023-10-16",
})

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // In a real application, you would:
    // 1. Validate the user's token
    // 2. Get the Stripe customer ID for the user
    // 3. Fetch charges for that customer

    // For this example, we'll return mock data
    // In a real app, you would use:
    // const charges = await stripe.charges.list({ customer: customerId, limit: 10 });

    const mockPaymentHistory = [
      {
        id: "ch_1NxYZ2CZ6qsJgndJQK3X0A1B",
        amount: 10000, // $100.00
        date: new Date().toISOString(),
        status: "succeeded",
        description: "Campaign boost - March 2025",
      },
      {
        id: "ch_2MxYZ2CZ6qsJgndJQK3X0A1C",
        amount: 5000, // $50.00
        date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
        status: "succeeded",
        description: "Monthly subscription - February 2025",
      },
      {
        id: "ch_3LxYZ2CZ6qsJgndJQK3X0A1D",
        amount: 5000, // $50.00
        date: new Date(Date.now() - 37 * 24 * 60 * 60 * 1000).toISOString(), // 37 days ago
        status: "succeeded",
        description: "Monthly subscription - January 2025",
      },
    ]

    return NextResponse.json(mockPaymentHistory)
  } catch (error) {
    console.error("Payment history error:", error)
    return NextResponse.json(
      { message: "Failed to fetch payment history", error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

