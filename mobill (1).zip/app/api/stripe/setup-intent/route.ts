import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

// Initialize Stripe with your secret key
// In a real app, this would come from an environment variable
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_your_key", {
  apiVersion: "2023-10-16",
})

export async function POST(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // In a real application, you would:
    // 1. Validate the user's token
    // 2. Get or create a Stripe customer for the user
    // 3. Create a SetupIntent for that customer

    // For this example, we'll create a SetupIntent without a customer
    const setupIntent = await stripe.setupIntents.create({
      payment_method_types: ["card"],
      usage: "off_session", // Allow the payment method to be used for future payments
      payment_method_options: {
        card: {
          request_three_d_secure: "automatic",
        },
      },
      // Add metadata to track the source
      metadata: {
        source: "mobill_app",
      },
    })

    return NextResponse.json({ clientSecret: setupIntent.client_secret })
  } catch (error) {
    console.error("Stripe setup intent error:", error)
    return NextResponse.json(
      { message: "Failed to create setup intent", error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

