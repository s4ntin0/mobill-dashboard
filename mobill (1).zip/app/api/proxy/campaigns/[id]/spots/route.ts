import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get the campaign ID from the URL
    const id = params.id

    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API with the correct path
    const apiUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/core/campaigns/${id}/spots`
    console.log(`Fetching campaign spots from: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // If the response is not OK
    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.error(`API responded with status ${response.status}: ${errorText}`)

      return NextResponse.json(
        {
          message: "Failed to fetch campaign spots",
          details: response.status === 404 ? "Spots not found" : "Error fetching spots",
        },
        { status: response.status },
      )
    }

    // Get the response data
    const data = await response.json().catch(() => null)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Campaign spots proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the campaign spots service" }, { status: 503 })
  }
}

