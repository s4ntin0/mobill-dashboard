import { type NextRequest, NextResponse } from "next/server"
import { generateSampleAdLogs } from "@/lib/ad-logs-service"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get the campaign ID from the URL
    const id = params.id

    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Parse query parameters
    const url = new URL(request.url)
    const page = Number.parseInt(url.searchParams.get("page") || "1", 10)
    const pageSize = Number.parseInt(url.searchParams.get("page_size") || "100", 10)

    // In a real implementation, you would make a request to your backend API
    // For now, we'll generate sample data
    const sampleLogs = generateSampleAdLogs(id, 20)

    // Return the sample data
    return NextResponse.json({
      data: sampleLogs,
      total_count: sampleLogs.length,
      page: page,
      page_size: pageSize,
    })
  } catch (error) {
    console.error("Ad logs proxy error:", error)
    return NextResponse.json({ message: "Failed to fetch ad display logs" }, { status: 503 })
  }
}

