import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get the campaign ID from the URL
    const id = params.id

    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API with the correct path
    // Add user_campaigns_only parameter to ensure we only get campaigns for the current user
    const apiUrl = new URL(`https://api.mobill.com/api/v1/core/campaigns/${id}/`)
    apiUrl.searchParams.append("user_campaigns_only", "true")

    console.log(`Fetching campaign details from: ${apiUrl.toString()}`)

    const response = await fetch(apiUrl, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // If the response is not OK (e.g., 404 Not Found or 403 Forbidden)
    if (!response.ok) {
      // This could happen if the campaign doesn't exist or doesn't belong to the user
      const errorText = await response.text().catch(() => "Unknown error")
      console.error(`API responded with status ${response.status}: ${errorText}`)

      return NextResponse.json(
        {
          message: "Campaign not found or access denied",
          details: response.status === 404 ? "Campaign not found" : "You don't have access to this campaign",
        },
        { status: response.status },
      )
    }

    // Get the response data
    const data = await response.json().catch(() => null)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Campaign proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the campaign service" }, { status: 503 })
  }
}

// Add PUT handler for campaign updates
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get the campaign ID from the URL
    const id = params.id

    // Get the authorization header and request body
    const authHeader = request.headers.get("authorization")
    const body = await request.json()

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    console.log(`Proxying campaign update for ID ${id} with data:`, JSON.stringify(body, null, 2))

    // Make the request to the API with the correct path
    const apiUrl = `https://api.mobill.com/api/v1/core/campaigns/${id}/`
    console.log(`Sending PUT request to: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      method: "PUT", // Using PUT for updates
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      cache: "no-store",
    })

    console.log(`API response status: ${response.status}`)

    // If the response is not OK, try to get more detailed error information
    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.error(`API responded with status ${response.status}: ${errorText}`)

      // Try to parse as JSON if possible
      try {
        const errorData = JSON.parse(errorText)
        return NextResponse.json(errorData, { status: response.status })
      } catch (parseError) {
        // If parsing fails, return the text
        return NextResponse.json(
          {
            message: "Failed to update campaign",
            details: errorText.substring(0, 500),
          },
          { status: response.status },
        )
      }
    }

    // Get the response data
    const data = await response.json().catch(() => {
      console.error("Failed to parse JSON response from API")
      return null
    })

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Update campaign proxy error:", error)
    return NextResponse.json(
      {
        message: "Failed to update campaign",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 503 },
    )
  }
}

// Keep POST handler for backward compatibility, but now it will return an error
export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get the campaign ID from the URL
    const id = params.id

    console.log(`POST method received for campaign ${id}, but PUT is required for updates`)

    // Return a clear error message
    return NextResponse.json(
      {
        message: "Method not allowed for campaign updates",
        detail: "Please use PUT method instead of POST for campaign updates",
      },
      { status: 405 },
    )
  } catch (error) {
    console.error("Campaign proxy error:", error)
    return NextResponse.json({ message: "Failed to process request" }, { status: 500 })
  }
}

