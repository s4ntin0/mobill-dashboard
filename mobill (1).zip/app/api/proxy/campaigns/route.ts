import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Add user_id query parameter if provided in the request
    const url = new URL(request.url)
    const searchParams = new URLSearchParams(url.search)

    // Make the request to the API with the correct path
    // The API should filter campaigns by the authenticated user
    const apiUrl = new URL("https://api.mobill.com/api/v1/core/campaigns/")

    // Pass any query parameters from the original request
    for (const [key, value] of searchParams.entries()) {
      apiUrl.searchParams.append(key, value)
    }

    // Add a specific parameter to ensure filtering by the current user
    apiUrl.searchParams.append("user_campaigns_only", "true")

    console.log(`Fetching campaigns from: ${apiUrl.toString()}`)

    const response = await fetch(apiUrl, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // Get the response data
    let data
    try {
      data = await response.json()
    } catch (error) {
      console.error("Error parsing campaigns response:", error)
      return NextResponse.json({ message: "Invalid response from API" }, { status: 502 })
    }

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Campaigns proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the campaigns service" }, { status: 503 })
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get the authorization header and request body
    const authHeader = request.headers.get("authorization")
    const body = await request.json()

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    console.log("Creating campaign with data:", JSON.stringify(body, null, 2))

    // Make the request to the API with the correct path
    const apiUrl = "https://api.mobill.com/api/v1/core/campaigns/"
    console.log(`Sending POST request to: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      cache: "no-store",
    })

    // Check if the response is ok
    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.error(`API responded with status ${response.status}: ${errorText}`)
      return NextResponse.json(
        {
          message: "Failed to create campaign",
          status: response.status,
          details: errorText,
        },
        { status: response.status },
      )
    }

    // Get the response data
    const data = await response.json().catch(() => null)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Create campaign proxy error:", error)
    return NextResponse.json(
      {
        message: "Failed to create campaign",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 503 },
    )
  }
}

