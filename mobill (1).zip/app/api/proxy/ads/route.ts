import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Get the form data from the request
    const formData = await request.formData()

    // Log what we're uploading for debugging
    const file = formData.get("image") as File
    if (file) {
      console.log(`Uploading ad image: ${file.name}, size: ${file.size}, type: ${file.type}`)
    } else {
      console.warn("No image file found in form data")
      // Check what fields are present in the formData
      console.log("Form data fields:", [...formData.keys()])
    }

    // Make the request to the API
    const uploadUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/core/ads/`
    console.log(`Sending ad upload request to: ${uploadUrl}`)

    const response = await fetch(uploadUrl, {
      method: "POST",
      headers: {
        Authorization: authHeader,
        // Don't set Content-Type here, it will be set automatically with the boundary
      },
      body: formData,
    })

    // Check if the response is OK
    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error")
      console.error(`Ad upload failed with status ${response.status}: ${errorText}`)

      return NextResponse.json({ message: "Failed to upload ad", details: errorText }, { status: response.status })
    }

    // Parse the response
    const data = await response.json()

    // Return the response
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Ad upload proxy error:", error)
    return NextResponse.json(
      { message: "Failed to upload ad", error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API
    const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/core/ads/`, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // Try to parse the response as JSON
    try {
      const data = await response.json()
      return NextResponse.json(data, { status: response.status })
    } catch (error) {
      console.error("Error parsing ads response:", error)
      return NextResponse.json({ message: "Invalid response from API" }, { status: 502 })
    }
  } catch (error) {
    console.error("Ads proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the ads service" }, { status: 503 })
  }
}

