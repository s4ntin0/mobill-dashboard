import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API with the correct path
    const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/core/campaign-stats`, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // If response is not OK, log the error and return the error
    if (!response.ok) {
      console.warn(`Failed to fetch campaign stats: ${response.status} ${response.statusText}`)

      try {
        const errorData = await response.json()
        return NextResponse.json(errorData, { status: response.status })
      } catch (parseError) {
        return NextResponse.json({ message: "Failed to fetch campaign stats" }, { status: response.status })
      }
    }

    // Parse the response
    try {
      const data = await response.json()
      return NextResponse.json(data, { status: response.status })
    } catch (parseError) {
      console.error("Error parsing campaign stats response:", parseError)
      return NextResponse.json({ message: "Invalid response from API" }, { status: 502 })
    }
  } catch (error) {
    console.error("Campaign stats proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the campaign stats service" }, { status: 503 })
  }
}

