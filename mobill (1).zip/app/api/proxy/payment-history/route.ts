import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    console.log("Fetching payment history from API...")

    // Extract token for logging (only show first 10 chars)
    const token = authHeader.replace("Bearer ", "")
    console.log("Token preview (first 10 chars):", token.substring(0, 10) + "...")

    // Use the new API endpoint
    const apiUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/stripe/payment-history`
    console.log(`API URL: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
        "X-Debug-Info": "mobill-app-debugging",
      },
      cache: "no-store",
    })

    // Log the response status for debugging
    console.log(`Payment history API response status: ${response.status}`)
    console.log("Payment history API response headers:", Object.fromEntries(response.headers.entries()))

    if (!response.ok) {
      // Try to get more detailed error information
      let errorDetail = ""
      try {
        const errorText = await response.text()
        console.error(`Payment history API error response: ${errorText}`)
        errorDetail = errorText

        // Try to parse as JSON if possible
        try {
          const errorData = JSON.parse(errorText)
          console.error("Parsed error data:", errorData)

          // If the error is that the user has no payment history, return an empty array
          if (
            response.status === 404 ||
            errorData.detail?.includes("not found") ||
            errorData.message?.includes("no payment history")
          ) {
            console.log("User has no payment history, returning empty array")
            return NextResponse.json(
              {
                data: [],
                has_more: false,
                next_page: null,
                total_count: 0,
                payment_method_attached: false, // Add the payment_method_attached field
              },
              { status: 200 },
            )
          }
        } catch (parseError) {
          console.error("Error response is not valid JSON")
        }
      } catch (parseError) {
        console.error("Could not parse error response")
      }

      // Only return fallback data if we can't determine what's happening
      console.log("Returning fallback payment history data with demo flag")
      return NextResponse.json(
        {
          data: [],
          has_more: false,
          next_page: null,
          total_count: 0,
          payment_method_attached: false, // Default to false for fallback data
          is_demo_data: true,
        },
        { status: 200 },
      )
    }

    // Parse the response
    try {
      const data = await response.json()
      console.log(`Received ${data.data?.length || 0} payment records for user`)
      console.log(`Payment method attached: ${data.payment_method_attached ? "Yes" : "No"}`)
      return NextResponse.json(data)
    } catch (parseError) {
      console.error("Error parsing payment history response:", parseError)
      throw new Error("Failed to parse payment history response")
    }
  } catch (error) {
    console.error("Payment history proxy error:", error)

    // Return empty data instead of fallback data when there's an error
    return NextResponse.json(
      {
        data: [],
        has_more: false,
        next_page: null,
        total_count: 0,
        payment_method_attached: false, // Default to false for error responses
        error_message: error instanceof Error ? error.message : "Unknown error",
        is_error_response: true,
      },
      { status: 200 },
    )
  }
}

