import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API
    const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/core/statistics/`, {
      headers: {
        Authorization: authHeader,
        Accept: "application/json",
      },
      cache: "no-store",
    })

    // If response is not OK, log the error and return a fallback
    if (!response.ok) {
      console.warn(`Failed to fetch statistics: ${response.status} ${response.statusText}`)

      // Return fallback data
      return NextResponse.json(
        {
          impressions: 1200,
          active_campaigns: 2,
          this_month_hours: 300,
          today_hours: 4,
        },
        { status: 200 },
      )
    }

    // Try to parse the response as JSON
    try {
      const data = await response.json()
      return NextResponse.json(data, { status: response.status })
    } catch (error) {
      console.error("Error parsing statistics response:", error)

      // Return fallback data
      return NextResponse.json(
        {
          impressions: 1200,
          active_campaigns: 2,
          this_month_hours: 300,
          today_hours: 4,
        },
        { status: 200 },
      )
    }
  } catch (error) {
    console.error("Statistics proxy error:", error)

    // Return fallback data
    return NextResponse.json(
      {
        impressions: 1200,
        active_campaigns: 2,
        this_month_hours: 300,
        today_hours: 4,
      },
      { status: 200 },
    )
  }
}

