import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join("/")
    const apiUrl = `http://api.mobill.com/api/v1/${path}`

    // Get the request body and headers
    const body = await request.json().catch(() => null)
    const authHeader = request.headers.get("authorization")

    // Django often expects these headers
    const headers: HeadersInit = {
      "Content-Type": "application/json",
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest", // This helps Django identify AJAX requests
    }

    if (authHeader) {
      headers["Authorization"] = authHeader
    }

    // Get CSRF token from cookies if present
    const csrfToken = request.cookies.get("csrftoken")?.value
    if (csrfToken) {
      headers["X-CSRFToken"] = csrfToken
    }

    console.log(`Proxying POST request to: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      method: "POST",
      headers,
      body: body ? JSON.stringify(body) : undefined,
      // Add cache: 'no-store' to prevent caching
      cache: "no-store",
      // Include credentials to handle cookies
      credentials: "include",
    })

    // Create a new response
    const responseData = await response.json().catch(() => null)
    const newResponse = NextResponse.json(responseData, {
      status: response.status,
      statusText: response.statusText,
    })

    // Forward any cookies from the Django response
    response.headers.forEach((value, key) => {
      if (key.toLowerCase() === "set-cookie") {
        newResponse.headers.append("Set-Cookie", value)
      }
    })

    return newResponse
  } catch (error) {
    console.error("API proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the API" }, { status: 500 })
  }
}

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join("/")
    const apiUrl = `http://api.mobill.com/api/v1/${path}`

    // Get headers
    const authHeader = request.headers.get("authorization")

    // Django often expects these headers
    const headers: HeadersInit = {
      Accept: "application/json",
      "X-Requested-With": "XMLHttpRequest", // This helps Django identify AJAX requests
    }

    if (authHeader) {
      headers["Authorization"] = authHeader
    }

    console.log(`Proxying GET request to: ${apiUrl}`)

    const response = await fetch(apiUrl, {
      method: "GET",
      headers,
      // Add cache: 'no-store' to prevent caching
      cache: "no-store",
      // Include credentials to handle cookies
      credentials: "include",
    })

    // Create a new response
    const responseData = await response.json().catch(() => null)
    const newResponse = NextResponse.json(responseData, {
      status: response.status,
      statusText: response.statusText,
    })

    // Forward any cookies from the Django response
    response.headers.forEach((value, key) => {
      if (key.toLowerCase() === "set-cookie") {
        newResponse.headers.append("Set-Cookie", value)
      }
    })

    return newResponse
  } catch (error) {
    console.error("API proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the API" }, { status: 500 })
  }
}

