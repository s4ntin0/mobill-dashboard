import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    // Get the request body
    const formData = await request.formData()

    // Create a new FormData object to send to the API
    const apiFormData = new FormData()
    apiFormData.append("username", formData.get("username") as string)
    apiFormData.append("password", formData.get("password") as string)

    console.log("Attempting to login with username:", formData.get("username"))

    // Make the request to the API using the config
    const loginUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}${API_CONFIG.endpoints.auth.login}`
    console.log(`Sending login request to: ${loginUrl}`)

    const response = await fetch(loginUrl, {
      method: "POST",
      body: apiFormData,
      // Disable cache to prevent stale responses
      cache: "no-store",
    })

    // Get the response data
    const data = await response.json().catch(() => null)

    console.log("Login response status:", response.status)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Login proxy error:", error)
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    return NextResponse.json(
      {
        message: "Failed to connect to the authentication service",
        error: errorMessage,
      },
      { status: 503 },
    )
  }
}

