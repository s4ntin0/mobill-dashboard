import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    // Get the refresh token from the request body
    const body = await request.json()
    const refreshToken = body.refresh

    if (!refreshToken) {
      return NextResponse.json({ message: "Refresh token is required" }, { status: 400 })
    }

    console.log("Attempting to refresh token...")

    // Make the request to the API
    const response = await fetch(`${API_CONFIG.baseUrl}${API_CONFIG.apiPath}${API_CONFIG.endpoints.auth.refresh}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ refresh: refreshToken }),
      // Disable cache to prevent stale responses
      cache: "no-store",
    })

    // If the response is not OK, return the error
    if (!response.ok) {
      console.error("Token refresh failed:", response.status, response.statusText)

      try {
        const errorData = await response.json()
        return NextResponse.json(errorData, { status: response.status })
      } catch (parseError) {
        return NextResponse.json(
          { message: "Failed to refresh token", status: response.status },
          { status: response.status },
        )
      }
    }

    // Get the response data
    const data = await response.json().catch(() => null)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Token refresh proxy error:", error)
    return NextResponse.json(
      { message: "Failed to refresh token", error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}

