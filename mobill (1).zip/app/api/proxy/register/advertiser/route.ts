import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    // Get the request body
    const body = await request.json()

    console.log("Attempting to register advertiser with data:", JSON.stringify(body, null, 2))

    // Make the request to the API
    const registerUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/users/register/advertiser`
    console.log(`Sending registration request to: ${registerUrl}`)

    const response = await fetch(registerUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      // Disable cache to prevent stale responses
      cache: "no-store",
    })

    // Get the response data
    let data
    try {
      data = await response.json()
    } catch (error) {
      console.error("Error parsing registration response:", error)
      return NextResponse.json({ message: "Invalid response from API" }, { status: 502 })
    }

    console.log("Registration response status:", response.status)

    // Return the response with the same status code
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Registration proxy error:", error)
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    return NextResponse.json(
      {
        message: "Failed to connect to the registration service",
        error: errorMessage,
      },
      { status: 503 },
    )
  }
}

