import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader) {
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    // Make the request to the API - using the original path since this is an auth endpoint
    const response = await fetch("https://api.mobill.com/api/v1/users/logout", {
      method: "POST",
      headers: {
        Authorization: authHeader,
      },
      // Disable cache to prevent stale responses
      cache: "no-store",
    })

    // Return the response with the same status code
    return NextResponse.json({ message: "Logged out successfully" }, { status: response.status })
  } catch (error) {
    console.error("Logout proxy error:", error)
    return NextResponse.json({ message: "Failed to connect to the authentication service" }, { status: 503 })
  }
}

