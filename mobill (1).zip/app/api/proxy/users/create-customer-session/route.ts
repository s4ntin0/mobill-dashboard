import { type NextRequest, NextResponse } from "next/server"
import { API_CONFIG } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    // Log all request headers for debugging
    console.log("Request headers:", Object.fromEntries(request.headers.entries()))

    if (!authHeader) {
      console.error("Authorization header missing")
      return NextResponse.json({ message: "Authorization header is required" }, { status: 401 })
    }

    console.log("Making request to create customer session...")
    console.log(
      "Auth header format check:",
      authHeader.startsWith("Bearer ") ? "Valid Bearer format" : "Invalid format",
    )

    // Extract token for logging (only show first 10 chars)
    const token = authHeader.replace("Bearer ", "")
    console.log("Token preview (first 10 chars):", token.substring(0, 10) + "...")

    // Log the exact API URL being called - use the new endpoint
    const apiUrl = `${API_CONFIG.baseUrl}${API_CONFIG.apiPath}/stripe/create-customer-session`
    console.log("Calling API URL:", apiUrl)

    // Make the request to the API
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-Debug-Info": "mobill-app-debugging",
      },
      cache: "no-store",
    })

    console.log("Customer session API response status:", response.status)
    console.log("Customer session API response headers:", Object.fromEntries(response.headers.entries()))

    // Check if the response is OK
    if (!response.ok) {
      // Clone the response to read it twice
      const responseClone = response.clone()

      // Try to get the response as text first
      const errorText = await response.text()
      console.error(`Customer session creation failed with status ${response.status}: ${errorText}`)

      // Try to parse as JSON if possible
      let errorData = null
      try {
        errorData = JSON.parse(errorText)
        console.error("Parsed error data:", errorData)
      } catch (parseError) {
        console.error("Error response is not valid JSON")
      }

      return NextResponse.json(
        {
          message: "Failed to create customer session",
          details: errorText.substring(0, 500),
          status: response.status,
          statusText: response.statusText,
          errorData: errorData,
        },
        { status: response.status },
      )
    }

    // Parse the response
    let data
    try {
      data = await response.json()
      console.log("API response structure:", Object.keys(data))
      console.log("Response contains client_secret:", data.client_secret ? "Yes" : "No")
      console.log(
        "Response contains customer_session_client_secret:",
        data.customer_session_client_secret ? "Yes" : "No",
      )
      console.log(
        "Response contains payment_method_attached:",
        data.payment_method_attached !== undefined ? "Yes" : "No",
      )
    } catch (error) {
      console.error("Error parsing customer session response:", error)
      return NextResponse.json({ error: "Invalid JSON response" }, { status: 502 })
    }

    // Log the complete response data (with sensitive info redacted)
    const redactedData = { ...data }
    if (redactedData.client_secret) redactedData.client_secret = "[REDACTED]"
    if (redactedData.customer_session_client_secret) redactedData.customer_session_client_secret = "[REDACTED]"
    console.log("Complete API response (redacted):", redactedData)

    // Return the response
    return NextResponse.json(data, { status: response.status })
  } catch (error) {
    console.error("Customer session proxy error:", error)
    return NextResponse.json(
      {
        message: "Failed to create customer session",
        error: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}

