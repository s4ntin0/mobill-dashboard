"use client"

import { useEffect } from "react"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error("Global error:", error)
  }, [error])

  return (
    <html lang="en">
      <body>
        <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
          <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Application Error</h2>

            <div className="mb-6">
              <p className="text-gray-700 mb-4">
                We're sorry, but the application has encountered a critical error. Our team has been notified.
              </p>
              <p className="text-sm text-gray-500 border-l-4 border-gray-300 pl-3 py-2 mb-4">
                Error: {error.message || "Unknown error"}
              </p>
            </div>

            <button
              onClick={reset}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Try again
            </button>
          </div>
        </div>
      </body>
    </html>
  )
}

