"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Globe } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Logo } from "@/components/logo"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Login() {
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
  })
  const { login, loading, error, stayLoggedIn, setStayLoggedIn } = useAuth()
  const { language, setLanguage, t } = useLanguage()
  const [submitError, setSubmitError] = useState<string | null>(null)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCredentials((prev) => ({ ...prev, [name]: value }))
    // Clear errors when user types
    setSubmitError(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitError(null)

    try {
      await login(credentials.username, credentials.password, stayLoggedIn)
    } catch (error) {
      console.error("Form submission error:", error)
      if (error instanceof Error) {
        setSubmitError(error.message)
      } else {
        setSubmitError("An unexpected error occurred. Please try again.")
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header with logo on left, theme toggle and language selector on right */}
      <header className="w-full p-4 flex justify-between items-center">
        <Logo size="medium" />
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <div className="flex items-center">
            <Globe size={16} className="text-gray-400 dark:text-gray-500 mr-2" />
            <Select value={language} onValueChange={(value: "en" | "es") => setLanguage(value)}>
              <SelectTrigger className="w-[120px] bg-transparent border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300">
                <SelectValue placeholder={language === "en" ? "English" : "Español"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center px-4">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-semibold text-center mb-8 text-gray-800 dark:text-gray-200">
            {t("login.title")}
          </h2>

          {(error || submitError) && (
            <div className="bg-red-500 bg-opacity-20 border border-red-500 text-red-500 px-4 py-2 rounded mb-4">
              {error || submitError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block mb-2 text-gray-700 dark:text-gray-300">
                {t("login.username")}
              </label>
              <input
                type="text"
                id="username"
                name="username"
                className="w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={t("login.username")}
                value={credentials.username}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block mb-2 text-gray-700 dark:text-gray-300">
                {t("login.password")}
              </label>
              <input
                type="password"
                id="password"
                name="password"
                className="w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={t("login.password")}
                value={credentials.password}
                onChange={handleChange}
                required
              />
            </div>

            {/* Stay logged in checkbox */}
            <div className="flex items-center">
              <Checkbox
                id="stayLoggedIn"
                checked={stayLoggedIn}
                onCheckedChange={(checked) => setStayLoggedIn(!!checked)}
                className="bg-transparent border-gray-500 dark:border-gray-400 text-blue-600"
              />
              <Label htmlFor="stayLoggedIn" className="ml-2 text-gray-700 dark:text-gray-300 cursor-pointer">
                {t("login.stayLoggedIn") || "Stay logged in"}
              </Label>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              disabled={loading}
            >
              {loading ? `${t("general.loading")}...` : t("login.button")}
            </button>
          </form>

          <div className="text-center mt-6 text-gray-600 dark:text-gray-400">
            {t("login.noAccount")}{" "}
            <Link href="/signup" className="text-blue-600 dark:text-blue-400 hover:underline">
              {t("login.signup")}
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

