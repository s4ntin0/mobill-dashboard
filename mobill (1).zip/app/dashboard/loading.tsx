import { LoadingState } from "@/components/loading-state"

export default function DashboardLoading() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-1">Dashboard</h1>
          <p className="text-gray-600">Loading your campaign data...</p>
        </div>
      </div>

      <div className="min-h-[60vh] flex items-center justify-center">
        <LoadingState message="Loading your campaign data..." />
      </div>
    </div>
  )
}

