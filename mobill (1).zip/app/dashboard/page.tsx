"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { type Campaign, type CampaignSummary, type CampaignStats, getCampaignSummary } from "@/lib/campaign-service"
import { checkPaymentMethodStatus } from "@/lib/payment-service"
import { StatCard } from "@/components/stat-card"
import { CampaignCard } from "@/components/campaign-card"
import { CampaignForm } from "@/components/campaign-form"
import { BarChart2, Clock, Plus, Calendar, Activity, Filter, CreditCard, LogOut } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Logo } from "@/components/logo"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Dashboard() {
  const { user, loading: authLoading, refreshToken, logout } = useAuth()
  const [campaignData, setCampaignData] = useState<CampaignSummary | null>(null)
  const [campaignStats, setCampaignStats] = useState<CampaignStats | null>(null)
  const [allCampaigns, setAllCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showAllCampaigns, setShowAllCampaigns] = useState(false)
  const [paymentMethodStatus, setPaymentMethodStatus] = useState<{
    payment_method_attached: boolean
    loading: boolean
    error: string | null
  }>({
    payment_method_attached: false,
    loading: true,
    error: null,
  })
  const router = useRouter()

  // State for campaign form - keep only for editing
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | undefined>(undefined)

  const { t } = useLanguage()

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login")
      return
    }

    if (user) {
      fetchData()
      checkPaymentMethod()
    }
  }, [user, authLoading, router])

  // Add this function to check payment method status
  const checkPaymentMethod = async () => {
    if (!user?.tokens.access) return

    try {
      setPaymentMethodStatus((prev) => ({ ...prev, loading: true, error: null }))
      const status = await checkPaymentMethodStatus(user.tokens.access)

      console.log("Payment method status:", status)

      // Force payment_method_attached to true for testing
      // Remove this in production
      setPaymentMethodStatus({
        ...status,
        payment_method_attached: true,
      })
    } catch (error) {
      console.error("Error checking payment method:", error)
      setPaymentMethodStatus({
        payment_method_attached: false,
        loading: false,
        error: error instanceof Error ? error.message : "Unknown error checking payment method",
      })
    }
  }

  // Add this function to handle API requests with token refresh
  const fetchWithRefresh = async (url: string, options: RequestInit) => {
    if (!user?.tokens.access) {
      throw new Error("No access token available")
    }

    // First attempt with current token
    const response = await fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        Authorization: `Bearer ${user.tokens.access}`,
      },
    })

    // If unauthorized, try to refresh token
    if (response.status === 401) {
      console.log("Received 401 response, attempting to refresh token...")

      // Try to refresh the token
      const refreshed = await refreshToken()

      if (refreshed && user) {
        console.log("Token refreshed successfully, retrying request...")

        // Retry the request with the new token
        return fetch(url, {
          ...options,
          headers: {
            ...options.headers,
            Authorization: `Bearer ${user.tokens.access}`,
          },
        })
      } else {
        console.error("Token refresh failed")
        throw new Error("Session expired. Please log in again.")
      }
    }

    return response
  }

  // Update the fetchData function to use fetchWithRefresh
  const fetchData = async () => {
    if (!user?.tokens.access) return

    try {
      setLoading(true)
      setError(null) // Clear any previous errors

      try {
        // Add timestamp to prevent caching
        const timestamp = new Date().getTime()

        // Use our fetchWithRefresh helper
        const campaignsResponse = await fetchWithRefresh(
          `/api/proxy/campaigns?_t=${timestamp}&user_campaigns_only=true`,
          {
            headers: {
              Accept: "application/json",
            },
          },
        )

        const statsResponse = await fetchWithRefresh("/api/proxy/campaign-stats", {
          headers: {
            Accept: "application/json",
          },
        })

        if (!campaignsResponse.ok) {
          throw new Error(`Failed to fetch campaigns: ${campaignsResponse.status}`)
        }

        if (!statsResponse.ok) {
          throw new Error(`Failed to fetch stats: ${statsResponse.status}`)
        }

        const campaigns = await campaignsResponse.json()
        const stats = await statsResponse.json()

        console.log(`Fetched ${campaigns.length} campaigns for user: ${user.username}`)

        // Process the campaign data
        const processedCampaigns: Campaign[] = Array.isArray(campaigns)
          ? campaigns.map((campaign) => ({
              id: campaign.id || "",
              description: campaign.description || "",
              start: campaign.start || new Date().toISOString().split("T")[0],
              duration: campaign.duration || 7,
              ad: campaign.ad || 1,
              location: campaign.location || null,
              radius: campaign.radius || null,
              market: campaign.market || 1,
              daily_budget: campaign.daily_budget || "100.00",
              show_on_weekends: campaign.show_on_weekends !== undefined ? campaign.show_on_weekends : true,
              road_type: campaign.road_type || "Any",
              traffic_density: campaign.traffic_density || "Any",
              // Display fields
              impressions: typeof campaign.impressions === "number" ? campaign.impressions : 0,
              minutes: typeof campaign.minutes === "number" ? campaign.minutes : 0,
              budgetSpent: typeof campaign.budgetSpent === "number" ? campaign.budgetSpent : 0,
              status: campaign.status || "active",
              active: campaign.active !== undefined ? campaign.active : true,
              name: campaign.name || campaign.description || "Unnamed Campaign",
            }))
          : []

        setAllCampaigns(processedCampaigns)
        const summary = getCampaignSummary(processedCampaigns)
        setCampaignData(summary)
        setCampaignStats(stats)
      } catch (apiError) {
        console.error("API error:", apiError)

        // If it's already a token refresh error, rethrow it
        if (apiError instanceof Error && apiError.message.includes("Session expired")) {
          throw apiError
        }

        // Otherwise, rethrow the original error
        throw apiError
      }
    } catch (err) {
      console.error("Error fetching data:", err)

      // If it's a session expired error, redirect to login
      if (err instanceof Error && err.message.includes("Session expired")) {
        router.push("/login")
      }

      setError("Failed to load campaign data. Please try again later.")
      // Initialize empty data to prevent null reference errors
      setAllCampaigns([])
      setCampaignData({
        totalImpressions: 0,
        totalMinutes: 0,
        totalAssigned: 0,
        budgetSpent: 0,
        budgetRemaining: 0,
        activeCampaigns: [],
      })
    } finally {
      setLoading(false)
    }
  }

  const handleEditCampaign = (campaign: Campaign) => {
    setSelectedCampaign(campaign)
    setIsFormOpen(true)
  }

  const handleFormClose = () => {
    setIsFormOpen(false)
    setSelectedCampaign(undefined)
  }

  const handleFormSuccess = () => {
    fetchData()
  }

  // Update the toggleCampaignStatus function
  const toggleCampaignStatus = async (campaign: Campaign) => {
    if (!user?.tokens.access) return

    try {
      // Create a copy of the campaign with the active status toggled
      const updatedCampaign = {
        ...campaign,
        active: !campaign.active,
        status: !campaign.active ? "active" : "inactive",
      }

      // Update the campaign in the API using our fetchWithRefresh helper
      const url = `/api/proxy/campaigns/${campaign.id}`

      const response = await fetchWithRefresh(url, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          active: updatedCampaign.active,
          status: updatedCampaign.status,
          // Include all required fields
          description: campaign.description,
          daily_budget: campaign.daily_budget,
          duration: campaign.duration,
          market: campaign.market,
          ad: campaign.ad,
          // Include other fields that might be required
          start: campaign.start,
          show_on_weekends: campaign.show_on_weekends,
          road_type: campaign.road_type,
          traffic_density: campaign.traffic_density,
          // Include location data if it exists
          location: campaign.location,
          radius: campaign.radius,
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to update campaign: ${response.status}`)
      }

      // Update the local state
      setAllCampaigns((prevCampaigns) => prevCampaigns.map((c) => (c.id === campaign.id ? updatedCampaign : c)))

      // Refresh the campaign data to update the summary
      fetchData()
    } catch (error) {
      console.error("Error toggling campaign status:", error)
      // Show an error message to the user
      alert(t("campaign.toggleError"))
    }
  }

  // Get the campaigns to display based on the filter
  const campaignsToDisplay = showAllCampaigns ? allCampaigns : allCampaigns.filter((campaign) => campaign.active)

  // Function to handle redirecting to billing page with alert
  const handleRedirectToBilling = () => {
    // Show alert to the user
    alert("You need to add a payment method before creating campaigns.")
    // Redirect to billing page
    router.push("/billing")
  }

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="text-xl">Loading...</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="text-red-500">{error}</div>
      </div>
    )
  }

  if (!campaignData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="text-xl">No campaign data available</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 bg-background text-foreground">
      <div className="flex justify-between mb-6">
        <div className="flex items-center">
          <Logo size="medium" />
        </div>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link
            href="/billing"
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            <CreditCard size={18} />
            {t("dashboard.billing")}
          </Link>
          <button
            onClick={() => user && logout()}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-600 dark:text-gray-400 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-gray-800 dark:hover:text-gray-200"
            title={t("general.logout")}
          >
            <LogOut size={18} />
            {t("general.logout")}
          </button>
        </div>
      </div>

      {/* Campaign Stats Section */}
      {campaignStats && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">{t("dashboard.campaignStats")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title={t("dashboard.totalImpressions")}
              value={(campaignStats.impressions || 0).toLocaleString()}
              icon={<BarChart2 size={24} />}
            />
            <StatCard
              title={t("dashboard.activeCampaignsCount")}
              value={(campaignStats.active_campaigns || 0).toString()}
              icon={<Activity size={24} />}
            />
            <StatCard
              title={t("dashboard.thisMonthHours")}
              value={(campaignStats.this_month_hours || 0).toString()}
              icon={<Calendar size={24} />}
            />
            <StatCard
              title={t("dashboard.todayHours")}
              value={(campaignStats.today_hours || 0).toString()}
              icon={<Clock size={24} />}
            />
          </div>
        </div>
      )}

      {/* Campaign Filter and Create Campaign Button - Updated positioning */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <h2 className="text-2xl font-bold mr-4">{t("dashboard.campaigns")}</h2>

          {/* Moved Create Campaign button here */}
          {paymentMethodStatus.payment_method_attached ? (
            <Link
              href="/campaigns/create"
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <Plus size={18} />
              {t("dashboard.createCampaign")}
            </Link>
          ) : (
            <button
              onClick={handleRedirectToBilling}
              className="flex items-center gap-2 px-4 py-2 bg-gray-400 text-white rounded-md hover:bg-gray-500 cursor-pointer group relative"
              title="Add payment method to create campaigns"
            >
              <Plus size={18} />
              {t("dashboard.createCampaign")}
              <span className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                Payment method required
              </span>
            </button>
          )}
        </div>

        <div className="flex items-center space-x-3 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 p-3 rounded-lg shadow-sm">
          <Filter size={18} className="text-blue-600" />
          <div className="flex items-center space-x-2">
            <Switch
              id="show-all-campaigns"
              checked={showAllCampaigns}
              onCheckedChange={setShowAllCampaigns}
              className="data-[state=checked]:bg-blue-600"
            />
            <Label
              htmlFor="show-all-campaigns"
              className="text-sm font-medium text-gray-900 dark:text-gray-100 cursor-pointer"
            >
              {t("dashboard.showAllCampaigns")}
            </Label>
          </div>
        </div>
      </div>

      {/* Campaigns List */}
      {campaignsToDisplay.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campaignsToDisplay.map((campaign) => (
            <CampaignCard
              key={campaign.id}
              campaign={{
                ...campaign,
                impressions: campaign.impressions || 0,
                minutes: campaign.minutes || 0,
                budgetSpent: campaign.budgetSpent || 0,
              }}
              onEdit={handleEditCampaign}
              onToggleStatus={toggleCampaignStatus}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          {showAllCampaigns ? t("dashboard.noCampaigns") : t("dashboard.noActiveCampaigns")}
        </div>
      )}

      {/* Campaign Form Modal - only for editing */}
      <CampaignForm
        isOpen={isFormOpen}
        onClose={handleFormClose}
        onSuccess={handleFormSuccess}
        campaign={selectedCampaign}
        isEditing={true}
      />
    </div>
  )
}

