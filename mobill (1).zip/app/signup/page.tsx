"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useLanguage } from "@/lib/language-context"
import { Globe, ArrowLeft } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { Logo } from "@/components/logo"
import { ThemeToggle } from "@/components/theme-toggle"

interface FormData {
  username: string
  email: string
  password: string
  confirm_password: string
  contact_name: string
  contact_phone_number: string
  company_name: string
}

interface FormErrors {
  username?: string[]
  email?: string[]
  password?: string[]
  confirm_password?: string
  contact_name?: string[]
  contact_phone_number?: string[]
  company_name?: string[]
  non_field_errors?: string[]
  user?: string[]
  detail?: string
}

export default function SignupPage() {
  const router = useRouter()
  const { language, setLanguage, t } = useLanguage()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [formErrors, setFormErrors] = useState<FormErrors>({})

  const [formData, setFormData] = useState<FormData>({
    username: "",
    email: "",
    password: "",
    confirm_password: "",
    contact_name: "",
    contact_phone_number: "",
    company_name: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear specific field error when user types
    if (formErrors[name as keyof FormErrors]) {
      setFormErrors((prev) => ({ ...prev, [name]: undefined }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setFormErrors({})

    // Validate passwords match
    if (formData.password !== formData.confirm_password) {
      setFormErrors({ confirm_password: "Passwords do not match" })
      setLoading(false)
      return
    }

    try {
      // Prepare the data for the API
      const apiData = {
        user: {
          username: formData.username,
          email: formData.email,
          password: formData.password,
          password2: formData.confirm_password, // Add password2 field
        },
        contact_name: formData.contact_name,
        contact_phone_number: formData.contact_phone_number,
        company_name: formData.company_name,
      }

      // Send the registration request
      const response = await fetch("/api/proxy/register/advertiser", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(apiData),
      })

      const data = await response.json()

      if (!response.ok) {
        console.error("Registration failed:", data)

        // Handle API validation errors
        if (response.status === 400) {
          // Transform nested user errors if they exist
          const errors: FormErrors = { ...data }

          if (data.user && typeof data.user === "object" && !Array.isArray(data.user)) {
            // Handle nested user field errors
            Object.entries(data.user).forEach(([key, value]) => {
              errors[key as keyof FormErrors] = value as string[]
            })
          }

          setFormErrors(errors)
        } else {
          // Handle other types of errors
          setFormErrors({
            non_field_errors: [data.message || data.detail || "Registration failed. Please try again."],
          })
        }
        setLoading(false)
        return
      }

      // Registration successful
      setSuccess(true)

      // Redirect to login page after a delay
      setTimeout(() => {
        router.push("/login")
      }, 2000)
    } catch (error) {
      console.error("Registration error:", error)
      setFormErrors({
        non_field_errors: ["An unexpected error occurred. Please try again."],
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header with logo on left, theme toggle and language selector on right */}
      <header className="w-full p-4 flex justify-between items-center">
        <Logo size="medium" />
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <div className="flex items-center">
            <Globe size={16} className="text-gray-400 dark:text-gray-500 mr-2" />
            <Select value={language} onValueChange={(value: "en" | "es") => setLanguage(value)}>
              <SelectTrigger className="w-[120px] bg-transparent border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300">
                <SelectValue placeholder={t("login.language")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md">
          <div className="mb-6">
            <Link
              href="/login"
              className="flex items-center text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100"
            >
              <ArrowLeft className="mr-2" size={18} />
              Back to Login
            </Link>
          </div>

          <h2 className="text-2xl font-semibold text-center mb-8 text-gray-800 dark:text-gray-200">
            Advertiser Registration
          </h2>

          {success ? (
            <Alert
              variant="success"
              className="mb-6 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-700 dark:text-green-300"
            >
              <AlertTitle>Registration Successful!</AlertTitle>
              <AlertDescription>
                Your account has been created. You will be redirected to the login page shortly.
              </AlertDescription>
            </Alert>
          ) : (
            <form onSubmit={handleSubmit}>
              {formErrors.non_field_errors && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-2 rounded mb-4">
                  {formErrors.non_field_errors.join(", ")}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Account Information Column */}
                <div>
                  <h3 className="text-lg font-medium mb-3 text-gray-700 dark:text-gray-300">Account Information</h3>

                  <div className="mb-4">
                    <label htmlFor="username" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Username*
                    </label>
                    <input
                      type="text"
                      id="username"
                      name="username"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.username ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Username"
                      value={formData.username}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.username && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.username.join(", ")}</p>
                    )}
                  </div>

                  <div className="mb-4">
                    <label htmlFor="email" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Email*
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.email ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.email && <p className="text-red-500 text-sm mt-1">{formErrors.email.join(", ")}</p>}
                  </div>

                  <div className="mb-4">
                    <label htmlFor="password" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Password*
                    </label>
                    <input
                      type="password"
                      id="password"
                      name="password"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.password ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Password"
                      value={formData.password}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.password && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.password.join(", ")}</p>
                    )}
                  </div>

                  <div className="mb-4 md:mb-0">
                    <label htmlFor="confirm_password" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Confirm Password*
                    </label>
                    <input
                      type="password"
                      id="confirm_password"
                      name="confirm_password"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.confirm_password ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Confirm Password"
                      value={formData.confirm_password}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.confirm_password && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.confirm_password}</p>
                    )}
                  </div>
                </div>

                {/* Company Information Column */}
                <div>
                  <h3 className="text-lg font-medium mb-3 text-gray-700 dark:text-gray-300">Company Information</h3>

                  <div className="mb-4">
                    <label htmlFor="company_name" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Company Name*
                    </label>
                    <input
                      type="text"
                      id="company_name"
                      name="company_name"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.company_name ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Company Name"
                      value={formData.company_name}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.company_name && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.company_name.join(", ")}</p>
                    )}
                  </div>

                  <div className="mb-4">
                    <label htmlFor="contact_name" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Contact Name*
                    </label>
                    <input
                      type="text"
                      id="contact_name"
                      name="contact_name"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.contact_name ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Contact Name"
                      value={formData.contact_name}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.contact_name && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.contact_name.join(", ")}</p>
                    )}
                  </div>

                  <div className="mb-4">
                    <label htmlFor="contact_phone_number" className="block mb-2 text-gray-700 dark:text-gray-300">
                      Contact Phone Number*
                    </label>
                    <input
                      type="tel"
                      id="contact_phone_number"
                      name="contact_phone_number"
                      className={`w-full px-4 py-3 rounded-md border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 ${formErrors.contact_phone_number ? "border-red-500 dark:border-red-500" : ""}`}
                      placeholder="Contact Phone Number"
                      value={formData.contact_phone_number}
                      onChange={handleChange}
                      required
                    />
                    {formErrors.contact_phone_number && (
                      <p className="text-red-500 text-sm mt-1">{formErrors.contact_phone_number.join(", ")}</p>
                    )}
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 mt-6"
                disabled={loading}
              >
                {loading ? "Registering..." : "Register"}
              </button>
            </form>
          )}

          <div className="text-center mt-6 text-gray-600 dark:text-gray-400">
            Already have an account?{" "}
            <Link href="/login" className="text-blue-600 dark:text-blue-400 hover:underline">
              Log in
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

