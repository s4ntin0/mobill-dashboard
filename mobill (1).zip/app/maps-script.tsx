"use client"

import Script from "next/script"
import { useState } from "react"

export default function MapsScript() {
  const [scriptError, setScriptError] = useState<boolean>(false)

  // Use the provided API key directly
  const apiKey = "AIzaSyCiO-QxdVxTrdWmWnzAOnHEhWdugGJLE_k"

  // Handle script load error
  const handleError = () => {
    console.error("Google Maps script failed to load")
    setScriptError(true)
    // Set a global flag that other components can check
    if (typeof window !== "undefined") {
      window.googleMapsLoadError = true
      window.dispatchEvent(new Event("google-maps-error"))
    }
  }

  // Handle script load success
  const handleLoad = () => {
    console.log("Google Maps script loaded successfully")
  }

  return (
    <>
      <Script
        src={`https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=visualization,marker&v=weekly`}
        strategy="beforeInteractive"
        onError={handleError}
        onLoad={handleLoad}
      />
      {scriptError && (
        <div className="hidden">Google Maps failed to load. Please check your API key configuration.</div>
      )}
    </>
  )
}

