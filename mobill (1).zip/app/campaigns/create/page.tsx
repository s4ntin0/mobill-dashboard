"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import {
  createCampaign,
  type Campaign,
  type Ad,
  type Market,
  type RoadType,
  type TrafficDensity,
  getAds,
  getMarkets,
  getRoadTypes,
  getTrafficDensities,
  uploadAd,
} from "@/lib/campaign-service"
import { formatPoint } from "@/lib/location-utils"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Checkbox } from "@/components/ui/checkbox"
import { useLanguage } from "@/lib/language-context"
import { AdUpload } from "@/components/ad-upload"
import { Switch } from "@/components/ui/switch"

export default function CreateCampaignPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dataLoading, setDataLoading] = useState(true)

  // Data states
  const [ads, setAds] = useState<Ad[]>([])
  const [markets, setMarkets] = useState<Market[]>([])
  const [roadTypes, setRoadTypes] = useState<RoadType[]>([])
  const [trafficDensities, setTrafficDensities] = useState<TrafficDensity[]>([])

  // Location state
  const [longitude, setLongitude] = useState<string>("-3.690457132960527")
  const [latitude, setLatitude] = useState<string>("40.18760661754005")
  const [useLocation, setUseLocation] = useState(false)

  // Add these state variables inside the component
  const { t } = useLanguage()
  const [contentFile, setContentFile] = useState<File | null>(null)
  const [contentDescription, setContentDescription] = useState("")
  // Update the state variables
  const [adFile, setAdFile] = useState<File | null>(null)
  const [adName, setAdName] = useState("")
  const [adDescription, setAdDescription] = useState("")
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadError, setUploadError] = useState<string | null>(null)

  // Initialize with default values that match the API requirements
  const [formData, setFormData] = useState<Omit<Campaign, "id">>({
    description: "Test Campaign",
    start: new Date().toISOString().split("T")[0], // Just the date part
    duration: 7, // Default 7 days
    ad: 1, // Default ad ID
    location: null, // Default to no location
    radius: null, // Default to no radius
    market: 1, // Default market ID
    daily_budget: "100.00", // Default daily budget
    show_on_weekends: true,
    road_type: "any", // Changed from "Any" to "any"
    traffic_density: "any", // Changed from "Any" to "any"
  })

  // Fetch dropdown data
  useEffect(() => {
    const fetchData = async () => {
      if (!user?.tokens.access) return

      try {
        setDataLoading(true)

        // Fetch data in parallel
        const [adsData, marketsData, roadTypesData, trafficDensitiesData] = await Promise.all([
          getAds(user.tokens.access),
          getMarkets(user.tokens.access),
          getRoadTypes(),
          getTrafficDensities(),
        ])

        setAds(adsData)
        setMarkets(marketsData)
        setRoadTypes(roadTypesData)
        setTrafficDensities(trafficDensitiesData)
      } catch (err) {
        console.error("Error fetching form data:", err)
        setError("Failed to load form data. Please try again.")
      } finally {
        setDataLoading(false)
      }
    }

    fetchData()
  }, [user])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: Number.parseInt(value, 10) }))
  }

  const handleBooleanChange = (name: string, value: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    if (name === "road_type" || name === "traffic_density") {
      setFormData((prev) => ({ ...prev, [name]: value }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: Number.parseInt(value, 10) }))
    }
  }

  const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    if (name === "longitude") {
      setLongitude(value)
      if (useLocation) {
        // Update the location in GeoJSON Point format
        setFormData((prev) => ({
          ...prev,
          location: formatPoint(Number.parseFloat(value) || 0, Number.parseFloat(latitude) || 0),
        }))
      }
    } else if (name === "latitude") {
      setLatitude(value)
      if (useLocation) {
        // Update the location in GeoJSON Point format
        setFormData((prev) => ({
          ...prev,
          location: formatPoint(Number.parseFloat(longitude) || 0, Number.parseFloat(value) || 0),
        }))
      }
    }
  }

  const toggleLocationUsage = (checked: boolean) => {
    setUseLocation(checked)
    if (checked) {
      // Enable location targeting
      setFormData((prev) => ({
        ...prev,
        location: formatPoint(Number.parseFloat(longitude) || 0, Number.parseFloat(latitude) || 0),
        radius: 1000,
      }))
    } else {
      // Disable location targeting
      setFormData((prev) => ({
        ...prev,
        location: null,
        radius: null,
      }))
    }
  }

  // Add this function to handle file changes
  const handleFileChange = (file: File | null, description: string) => {
    setContentFile(file)
    setContentDescription(description)
    setUploadError(null)
  }

  // Update the file change handler
  const handleAdFileChange = (file: File | null, name: string, description: string) => {
    setAdFile(file)
    setAdName(name)
    setAdDescription(description)
    setUploadError(null)
  }

  // Update the handleSubmit function to include file upload
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setUploadError(null)

    try {
      if (!user?.tokens.access) {
        throw new Error("You must be logged in")
      }

      // First, upload the ad if one is selected
      let adId = null
      if (adFile) {
        try {
          setUploadProgress(10)
          setUploadProgress(30)

          const uploadedAd = await uploadAd(adFile, adName, adDescription, user.tokens.access)
          adId = uploadedAd.id

          setUploadProgress(100)
        } catch (uploadError) {
          console.error("Ad upload error:", uploadError)
          setUploadError(uploadError instanceof Error ? uploadError.message : "Ad upload failed")
          setLoading(false)
          return
        }
      }

      // Format the data according to API requirements
      const campaignData = {
        ...formData,
        // Ensure proper formatting for specific fields
        daily_budget: formData.daily_budget.toString(),
        // Only include location if it's being used
        location: useLocation ? formatPoint(Number.parseFloat(longitude), Number.parseFloat(latitude)) : null,
        radius: useLocation ? formData.radius : null,
        // Add ad ID if a file was uploaded
        ...(adId && { ad: adId }),
      }

      console.log("Submitting campaign data:", campaignData)

      await createCampaign(campaignData, user.tokens.access)
      router.push("/dashboard")
    } catch (err) {
      console.error("Campaign form error:", err)
      if (err instanceof Error) {
        setError(err.message)
      } else {
        setError("An unexpected error occurred")
      }
    } finally {
      setLoading(false)
      setUploadProgress(0)
    }
  }

  if (dataLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="flex justify-center items-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p>Loading campaign data...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-6">
        <Link href="/dashboard" className="flex items-center text-gray-700 hover:text-gray-900">
          <ArrowLeft className="mr-2" size={18} />
          Back to Dashboard
        </Link>
      </div>

      <h1 className="text-3xl font-bold mb-6 text-black">Create New Campaign</h1>

      {error && (
        <div className="bg-red-500 bg-opacity-20 border border-red-500 text-red-500 px-4 py-2 rounded mb-4">
          {error}
        </div>
      )}

      <div className="bg-gray-100 p-6 rounded-lg border border-gray-200 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Campaign Information */}
          <div className="border-b border-gray-300 pb-4 mb-4">
            <h2 className="text-xl font-semibold mb-4 text-black">Basic Information</h2>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-gray-800">
                Campaign Description
              </Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={3}
                required
                className="bg-white text-black border-gray-300"
                placeholder="Describe your campaign"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div className="space-y-2">
                <Label htmlFor="start" className="text-gray-800">
                  Start Date
                </Label>
                <Input
                  id="start"
                  name="start"
                  type="date"
                  value={formData.start}
                  onChange={handleChange}
                  required
                  className="bg-white text-black border-gray-300"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="duration" className="text-gray-800">
                  Duration (Days)
                </Label>
                <Input
                  id="duration"
                  name="duration"
                  type="number"
                  min="1"
                  value={formData.duration}
                  onChange={handleNumberChange}
                  required
                  className="bg-white text-black border-gray-300"
                  placeholder="7"
                />
                <p className="text-xs text-gray-500">Number of days the campaign will run</p>
              </div>
            </div>

            {/* Budget field moved here from the bottom */}
            <div className="space-y-2 mt-4">
              <Label htmlFor="daily_budget" className="text-gray-800">
                Daily Budget
              </Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                <Input
                  id="daily_budget"
                  name="daily_budget"
                  type="text"
                  value={formData.daily_budget}
                  onChange={handleChange}
                  required
                  className="bg-white text-black border-gray-300 pl-8"
                  placeholder="100.00"
                />
              </div>
              <p className="text-xs text-gray-500">Maximum amount to spend per day</p>
            </div>
          </div>

          {/* Content and Market Selection */}
          <div className="border-b border-gray-300 pb-4 mb-4">
            <h2 className="text-xl font-semibold mb-4 text-black">Content & Market</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="ad" className="text-gray-800">
                  Advertisement
                </Label>
                <Select value={formData.ad.toString()} onValueChange={(value) => handleSelectChange("ad", value)}>
                  <SelectTrigger id="ad" className="bg-white text-black border-gray-300">
                    <SelectValue placeholder="Select advertisement" />
                  </SelectTrigger>
                  <SelectContent>
                    {ads.map((ad) => (
                      <SelectItem key={ad.id} value={ad.id.toString()}>
                        {/* Fix the ad name display */}
                        {ad.name || ad.description || `Ad #${ad.id}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="market" className="text-gray-800">
                  Market
                </Label>
                <Select
                  value={formData.market.toString()}
                  onValueChange={(value) => handleSelectChange("market", value)}
                >
                  <SelectTrigger id="market" className="bg-white text-black border-gray-300">
                    <SelectValue placeholder="Select market" />
                  </SelectTrigger>
                  <SelectContent>
                    {markets.map((market) => (
                      <SelectItem key={market.id} value={market.id.toString()}>
                        {market.name} ({market.city}, {market.country})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Location Targeting */}
          <div className="border-b border-gray-300 pb-4 mb-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-black">{t("campaign.locationTargeting")}</h2>
              <div className="flex items-center space-x-2">
                <Switch
                  id="useLocation"
                  checked={useLocation}
                  onCheckedChange={toggleLocationUsage}
                  className="data-[state=checked]:bg-blue-600"
                />
                <Label htmlFor="useLocation" className="text-sm font-medium text-gray-700 cursor-pointer">
                  {useLocation ? t("campaign.disableLocation") : t("campaign.enableLocation")}
                </Label>
              </div>
            </div>

            {useLocation ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                  <div className="space-y-2">
                    <Label htmlFor="longitude" className="text-gray-800">
                      Longitude
                    </Label>
                    <Input
                      id="longitude"
                      name="longitude"
                      type="text"
                      value={longitude}
                      onChange={handleLocationChange}
                      required={useLocation}
                      className="bg-white text-black border-gray-300"
                      placeholder="-3.690457132960527"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="latitude" className="text-gray-800">
                      Latitude
                    </Label>
                    <Input
                      id="latitude"
                      name="latitude"
                      type="text"
                      value={latitude}
                      onChange={handleLocationChange}
                      required={useLocation}
                      className="bg-white text-black border-gray-300"
                      placeholder="40.18760661754005"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="radius" className="text-gray-800">
                    Radius (meters)
                  </Label>
                  <Input
                    id="radius"
                    name="radius"
                    type="number"
                    min="100"
                    max="10000"
                    value={formData.radius || 1000}
                    onChange={handleNumberChange}
                    required={useLocation}
                    className="bg-white text-black border-gray-300"
                  />
                  <p className="text-xs text-gray-500">Target area radius in meters (100m - 10km)</p>
                </div>
              </>
            ) : (
              <p className="text-gray-500 italic">
                Location targeting is disabled. Campaigns will be shown across the selected market.
              </p>
            )}
          </div>

          {/* Targeting Options */}
          <div className="border-b border-gray-300 pb-4 mb-4">
            <h2 className="text-xl font-semibold mb-4 text-black">Targeting Options</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div className="space-y-2">
                <Label htmlFor="road_type" className="text-gray-800">
                  Road Type
                </Label>
                <Select value={formData.road_type} onValueChange={(value) => handleSelectChange("road_type", value)}>
                  <SelectTrigger id="road_type" className="bg-white text-black border-gray-300">
                    <SelectValue placeholder="Select road type" />
                  </SelectTrigger>
                  <SelectContent>
                    {roadTypes.map((roadType) => (
                      <SelectItem key={roadType.id} value={roadType.id}>
                        {roadType.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">Type of roads where ads will be displayed</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="traffic_density" className="text-gray-800">
                  Traffic Density
                </Label>
                <Select
                  value={formData.traffic_density}
                  onValueChange={(value) => handleSelectChange("traffic_density", value)}
                >
                  <SelectTrigger id="traffic_density" className="bg-white text-black border-gray-300">
                    <SelectValue placeholder="Select traffic density" />
                  </SelectTrigger>
                  <SelectContent>
                    {trafficDensities.map((density) => (
                      <SelectItem key={density.id} value={density.id}>
                        {density.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">Target specific traffic conditions</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="show_on_weekends"
                  checked={formData.show_on_weekends}
                  onCheckedChange={(checked) => handleBooleanChange("show_on_weekends", !!checked)}
                />
                <Label htmlFor="show_on_weekends" className="text-gray-800 cursor-pointer">
                  Show on Weekends
                </Label>
              </div>
              <p className="text-xs text-gray-500 ml-6">Whether to display ads on weekends</p>
            </div>
          </div>

          {/* Add this section to the form, after the Targeting Options section and before the submit buttons */}
          {/* Update the form section for ad upload */}
          <div className="border-b border-gray-300 pb-4 mb-4">
            <h2 className="text-xl font-semibold mb-4 text-black">{t("campaign.adUpload")}</h2>
            <p className="text-gray-500 mb-4">{t("campaign.adUploadDescription")}</p>

            <AdUpload onFileChange={handleAdFileChange} initialName={adName} initialDescription={adDescription} />

            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="mt-4">
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {t("campaign.uploadingAd")}: {uploadProgress}%
                </p>
              </div>
            )}

            {uploadError && (
              <div className="mt-4 bg-red-500 bg-opacity-20 border border-red-500 text-red-500 px-4 py-2 rounded">
                {uploadError}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-4 pt-4">
            <Link
              href="/dashboard"
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 bg-white"
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              disabled={loading}
            >
              {loading ? "Creating..." : "Create Campaign"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

