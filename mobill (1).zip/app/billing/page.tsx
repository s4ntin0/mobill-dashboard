"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { useLanguage } from "@/lib/language-context"
import { useRouter } from "next/navigation"
import { StripePaymentElement } from "@/components/stripe-payment-element"
import {
  CreditCard,
  ArrowLeft,
  CheckCircle,
  RefreshCw,
  ExternalLink,
  Calendar,
  CreditCardIcon as CardIcon,
} from "lucide-react"
import Link from "next/link"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { Logo } from "@/components/logo"
import { ThemeToggle } from "@/components/theme-toggle"

interface PaymentRecord {
  id: string
  amount: number
  currency: string
  status: string
  created: number
  payment_method_type: string
  receipt_url: string
  description: string
  metadata: Record<string, any>
}

interface PaymentHistoryResponse {
  data: PaymentRecord[]
  has_more: boolean
  next_page: string | null
  total_count: number
  payment_method_attached: boolean // Add this field to track if payment method is attached
}

export default function BillingPage() {
  const { user, loading: authLoading } = useAuth()
  const { t } = useLanguage()
  const router = useRouter()
  const [setupIntentClientSecret, setSetupIntentClientSecret] = useState<string | null>(null)
  const [customerSessionClientSecret, setCustomerSessionClientSecret] = useState<string | null>(null)
  const [paymentHistory, setPaymentHistory] = useState<PaymentRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [paymentHistoryError, setPaymentHistoryError] = useState<string | null>(null)
  const [showSuccessAlert, setShowSuccessAlert] = useState(false)
  const [totalPayments, setTotalPayments] = useState<number>(0)
  const [paymentMethodAttached, setPaymentMethodAttached] = useState<boolean>(false)

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login")
      return
    }

    if (user) {
      // Fetch the customer session client secret
      fetchCustomerSession()
      // Fetch payment history
      fetchPaymentHistory()
    }
  }, [user, authLoading, router])

  const fetchCustomerSession = async () => {
    if (!user?.tokens.access) return

    try {
      console.log("Fetching customer session...")
      setError(null)

      const response = await fetch("/api/proxy/users/create-customer-session", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${user.tokens.access}`,
          "Content-Type": "application/json",
        },
      })

      console.log("Customer session response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text().catch(() => "Unknown error")
        console.error(`Failed to create customer session: ${response.status} ${response.statusText}`)
        console.error("Error response:", errorText)
        throw new Error(`Failed to create customer session: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      // Log the complete response
      console.log("Complete API response:", data)

      // Check if payment method is attached
      if (data.payment_method_attached !== undefined) {
        setPaymentMethodAttached(data.payment_method_attached)
        console.log("Payment method attached:", data.payment_method_attached)
      }

      // Handle both client_secret and customer_session_client_secret
      if (data.client_secret) {
        setSetupIntentClientSecret(data.client_secret)
        console.log("SetupIntent client secret received")
      }

      if (data.customer_session_client_secret) {
        setCustomerSessionClientSecret(data.customer_session_client_secret)
        console.log("CustomerSession client secret received")
      }

      if (!data.customer_session_client_secret) {
        console.error("No customer_session_client_secret in response:", data)
        throw new Error("Invalid response: Missing customer session client secret")
      }
    } catch (err) {
      console.error("Error creating customer session:", err)
      setError(err instanceof Error ? err.message : "Failed to initialize payment form. Please try again later.")
      setSetupIntentClientSecret(null)
      setCustomerSessionClientSecret(null)
    }
  }

  const fetchPaymentHistory = async () => {
    if (!user?.tokens.access) return

    try {
      setLoading(true)
      setPaymentHistoryError(null)

      console.log("Fetching payment history...")

      const response = await fetch("/api/proxy/payment-history", {
        headers: {
          Authorization: `Bearer ${user.tokens.access}`,
        },
      })

      console.log("Payment history response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text().catch(() => "Unknown error")
        console.error(`Failed to fetch payment history: ${response.status} ${response.statusText}`)
        console.error("Error response:", errorText)
        setPaymentHistoryError("Could not load payment history. Please try again later.")
        setPaymentHistory([])
        setTotalPayments(0)
        return
      }

      const data = await response.json()

      // Check if payment method is attached from the response
      if (data.payment_method_attached !== undefined) {
        setPaymentMethodAttached(data.payment_method_attached)
        console.log("Payment method attached (from history):", data.payment_method_attached)
      }

      // Check if this is demo data and show a warning
      if (data.is_demo_data) {
        setPaymentHistoryError("Showing demo payment data. Your actual payment history could not be loaded.")
      }

      // Check if this is an error response
      if (data.is_error_response) {
        setPaymentHistoryError(`Could not load payment history: ${data.error_message || "Unknown error"}`)
        setPaymentHistory([])
        setTotalPayments(0)
        return
      }

      if (data && Array.isArray(data.data)) {
        setPaymentHistory(data.data)
        setTotalPayments(data.total_count || data.data.length)

        // If the array is empty, show a message
        if (data.data.length === 0) {
          setPaymentHistoryError(null) // Clear any previous errors
        }
      } else {
        console.error("Invalid payment history data format:", data)
        setPaymentHistoryError("Invalid payment history data format.")
        setPaymentHistory([])
        setTotalPayments(0)
      }
    } catch (err) {
      console.error("Error fetching payment history:", err)
      setPaymentHistoryError("Failed to fetch payment history.")
      setPaymentHistory([])
      setTotalPayments(0)
    } finally {
      setLoading(false)
    }
  }

  // Format currency amount from cents to dollars
  const formatAmount = (amount: number, currency = "usd") => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency.toUpperCase(),
    }).format(amount)
  }

  // Format date from Unix timestamp
  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Format payment method type
  const formatPaymentMethod = (type: string, last4?: string) => {
    const typeMap: Record<string, string> = {
      card: "Credit Card",
      sepa_debit: "SEPA Debit",
      ideal: "iDEAL",
      sofort: "Sofort",
      bancontact: "Bancontact",
      giropay: "Giropay",
      p24: "Przelewy24",
      eps: "EPS",
      alipay: "Alipay",
      wechat: "WeChat Pay",
    }

    const displayType = typeMap[type] || type.charAt(0).toUpperCase() + type.slice(1)
    return last4 ? `${displayType} (•••• ${last4})` : displayType
  }

  const handlePaymentMethodAdded = () => {
    setShowSuccessAlert(true)
    // Set payment method attached to true
    setPaymentMethodAttached(true)
    // Hide the alert after 5 seconds
    setTimeout(() => {
      setShowSuccessAlert(false)
    }, 5000)
  }

  const handleRetry = () => {
    fetchCustomerSession()
  }

  const handleRetryPaymentHistory = () => {
    fetchPaymentHistory()
  }

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="text-xl">Loading...</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl bg-background text-foreground">
      <div className="flex justify-between mb-6">
        <div className="flex flex-col items-center">
          <Logo size="medium" className="mb-2" />
          <Link
            href="/dashboard"
            className="flex items-center text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100"
          >
            <ArrowLeft className="mr-2" size={18} />
            Back to Dashboard
          </Link>
        </div>
        <ThemeToggle />
      </div>

      <h1 className="text-3xl font-bold mb-6">{t("billing.title")}</h1>

      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-md mb-6 flex justify-between items-center">
          <div>{error}</div>
          <button
            onClick={handleRetry}
            className="flex items-center text-red-700 dark:text-red-300 hover:text-red-800 dark:hover:text-red-200"
            aria-label="Retry"
          >
            <RefreshCw size={16} className="mr-1" />
            Retry
          </button>
        </div>
      )}

      {showSuccessAlert && (
        <Alert
          variant="success"
          className="mb-6 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-700 dark:text-green-300"
        >
          <CheckCircle className="h-4 w-4" />
          <AlertTitle>Payment method saved</AlertTitle>
          <AlertDescription>
            Your card has been successfully saved and is ready to use for future payments.
          </AlertDescription>
        </Alert>
      )}

      {/* Payment Method Status */}
      {paymentMethodAttached ? (
        <Alert
          variant="success"
          className="mb-6 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-700 dark:text-green-300"
        >
          <CheckCircle className="h-4 w-4" />
          <AlertTitle>Payment Method Active</AlertTitle>
          <AlertDescription>You have an active payment method on file. You can create campaigns.</AlertDescription>
        </Alert>
      ) : (
        <Alert className="mb-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300">
          <CreditCard className="h-4 w-4" />
          <AlertTitle>Add a Payment Method</AlertTitle>
          <AlertDescription>Please add a payment method below to start creating campaigns.</AlertDescription>
        </Alert>
      )}

      {/* Payment Method Section */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm mb-8">
        <div className="flex items-center mb-4">
          <CreditCard className="mr-2 text-blue-600 dark:text-blue-400" size={24} />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">{t("billing.paymentMethod")}</h2>
        </div>

        <StripePaymentElement
          setupIntentClientSecret={setupIntentClientSecret}
          customerSessionClientSecret={customerSessionClientSecret}
          onSuccess={handlePaymentMethodAdded}
        />
      </div>

      {/* Payment History Section */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">{t("billing.paymentHistory")}</h2>
          {totalPayments > 0 && (
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {totalPayments} {totalPayments === 1 ? "payment" : "payments"}
            </span>
          )}
        </div>

        {paymentHistoryError && (
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300 px-4 py-3 rounded-md mb-4 flex justify-between items-center">
            <div>{paymentHistoryError}</div>
            <button
              onClick={handleRetryPaymentHistory}
              className="flex items-center text-yellow-700 dark:text-yellow-300 hover:text-yellow-800 dark:hover:text-yellow-200"
              aria-label="Retry"
            >
              <RefreshCw size={16} className="mr-1" />
              Retry
            </button>
          </div>
        )}

        {loading ? (
          <div className="py-4 text-center text-gray-500 dark:text-gray-400">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 dark:border-blue-400 mx-auto mb-4"></div>
            <p>Loading payment history...</p>
          </div>
        ) : paymentHistory.length > 0 ? (
          <div className="space-y-4">
            {paymentHistory.map((payment) => (
              <div
                key={payment.id}
                className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-gray-50 dark:bg-gray-900"
              >
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-3">
                  <div className="flex items-center mb-2 md:mb-0">
                    <CardIcon className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-2" />
                    <span className="font-medium text-gray-800 dark:text-gray-200">
                      {formatPaymentMethod(payment.payment_method_type)}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <span
                      className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        payment.status === "succeeded"
                          ? "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300"
                          : payment.status === "pending"
                            ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300"
                            : "bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300"
                      }`}
                    >
                      {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col md:flex-row md:justify-between">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">
                      <Calendar className="h-4 w-4 inline mr-1" />
                      {formatDate(payment.created)}
                    </p>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {payment.description || "No description"}
                    </p>
                  </div>
                  <div className="mt-2 md:mt-0 md:text-right">
                    <p className="text-lg font-bold text-gray-900 dark:text-gray-100">
                      {formatAmount(payment.amount, payment.currency)}
                    </p>
                    {payment.receipt_url && (
                      <a
                        href={payment.receipt_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 flex items-center justify-start md:justify-end mt-1"
                      >
                        View Receipt
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            {paymentHistoryError ? (
              <div className="flex flex-col items-center">
                <p>{paymentHistoryError}</p>
                <button
                  onClick={handleRetryPaymentHistory}
                  className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Retry
                </button>
              </div>
            ) : (
              <p>{t("billing.noPayments")}</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

