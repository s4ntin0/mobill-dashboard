"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { CheckCircle } from "lucide-react"

export default function PaymentSuccess() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the billing page after a short delay
    const timer = setTimeout(() => {
      router.push("/billing")
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg border border-gray-200 shadow-md max-w-md w-full text-center">
        <CheckCircle className="mx-auto mb-4 text-green-500" size={64} />
        <h1 className="text-2xl font-bold mb-2">Payment Method Added</h1>
        <p className="text-gray-600 mb-6">Your payment method has been successfully saved.</p>
        <p className="text-sm text-gray-500">Redirecting you back to the billing page...</p>
      </div>
    </div>
  )
}

